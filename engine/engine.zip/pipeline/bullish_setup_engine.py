"""Calculation-owned bullish chart schematics; no order execution or trade ledger.

Native detectors retain formation, numbering and ownership. This stage consumes
their accepted immutable events and classifies the user's movement/entry rules.
"""
from __future__ import annotations

from bisect import bisect_left, bisect_right
from dataclasses import dataclass, field
from datetime import datetime
from decimal import Decimal
import heapq

from core_utils import as_decimal
from lifecycle_engine import sequence_priority
from reaction_engine import LowerTimeframeIndex

SETUP_VERSION = "1.0.0"


@dataclass(slots=True)
class StopAllAssessment:
    source_index: int
    source_time: datetime
    number: int
    decision_event_time: datetime
    scope_id: str
    ignored_prefix: bool
    reference_high: Decimal
    reference_source_index: int
    status: str | None = None
    status_event_time: datetime | None = None
    reason: str = "awaiting-stop-or-successor"
    predecessor_source_indexes: tuple[int, ...] = ()


@dataclass(slots=True)
class BehaviorAssessment:
    kind: str
    source_index: int
    source_time: datetime
    decision_event_time: datetime
    anchor_source_index: int
    status: str | None = None
    status_event_time: datetime | None = None


@dataclass(frozen=True, slots=True)
class SetupAnnotation:
    id: str
    anchor_kind: str
    anchor_number: int
    anchor_source_index: int
    anchor_source_time: datetime
    anchor_decision_event_time: datetime
    cycle_id: str | None
    behavior_kind: str | None
    behavior_source_index: int | None
    behavior_source_time: datetime | None
    confirmation_event_time: datetime
    entry_index: int
    entry_time: datetime
    close_event_time: datetime
    entry_price: Decimal
    stop_price: Decimal
    target_price: Decimal
    width_bars: int = 50
    risk_reward: Decimal = Decimal(4)


@dataclass(frozen=True, slots=True)
class ReferenceBreak:
    scope_id: str
    event_time: datetime
    source_index: int
    reference_high: Decimal
    reference_source_index: int


@dataclass(slots=True)
class SetupResult:
    assessments: list[StopAllAssessment] = field(default_factory=list)
    behaviors: list[BehaviorAssessment] = field(default_factory=list)
    setups: list[SetupAnnotation] = field(default_factory=list)
    breakouts: list[ReferenceBreak] = field(default_factory=list)
    phase: str = "stopall"


@dataclass(slots=True)
class _Scope:
    identity: str
    rows: list = field(default_factory=list)
    behaviors: list = field(default_factory=list)
    parity: dict = field(default_factory=lambda: {0: None, 1: None})
    priority: int | None = None
    break_scheduled: bool = False
    blocked: bool = False


@dataclass(slots=True)
class _Movement:
    root: int
    epoch: int
    prefix: int
    reference_high: Decimal
    reference_source_index: int
    source_time: datetime
    extent: int = 0
    scopes: dict = field(default_factory=dict)


def _native_chains(stopalls, stop_times):
    """Reproduce native max-stopped ancestry, including multi-chain joins."""
    active, roots, predecessors = [], {}, {}
    for item in sorted(stopalls, key=lambda r: (r.source_time, r.source_index)):
        key = int(item.source_index)
        if int(item.number) > 1:
            consumed = [r for r in active if stop_times[r.source_index] is not None
                        and stop_times[r.source_index] <= item.decision_event_time]
            candidates = [r for r in consumed if int(r.number) == int(item.number)-1]
            parent = max(candidates, key=lambda r: (r.source_time, r.source_index), default=None)
            roots[key] = roots[parent.source_index] if parent is not None else key
            predecessors[key] = tuple(r.source_index for r in consumed)
            consumed_ids = {r.source_index for r in consumed}
            active = [r for r in active if r.source_index not in consumed_ids]
        else:
            roots[key], predecessors[key] = key, ()
            if (str(getattr(item,"donor_type","")).upper() == "S"
                    or getattr(item,"gate_type",None) == "opposite-s-group-stop"):
                active = []
        active.append(item)
    return roots, predecessors


def calculate_bullish_setups(chronology, s_zones, e_zones, stopalls, primary_lows,
                             *, through_index=None):
    """Evaluate complete accepted history up to an inclusive main-candle horizon."""
    result = SetupResult()
    if not chronology.candles:
        return result
    end = min(len(chronology.candles)-1,
              len(chronology.candles)-1 if through_index is None else int(through_index))
    if end < 0:
        return result
    horizon = chronology.times[end] + chronology.timeframe
    lower_end = bisect_left(chronology.second_times, horizon)
    main_prices = LowerTimeframeIndex(chronology.candles)

    def crossing(event, price, *, above=False, inclusive=False):
        left = (bisect_left if inclusive else bisect_right)(chronology.second_times, event)
        query = chronology.lower_index.first_greater if above else chronology.lower_index.first_less
        position = query(left, lower_end, as_decimal(price))
        return None if position is None else chronology.second_times[position]

    native = [r for r in stopalls if r.direction == "bullish"
              and r.decision_event_time < horizon]
    stop_times = {r.source_index: getattr(r, "stop_event_time", None)
                  or crossing(r.decision_event_time, r.price, inclusive=True) for r in native}
    roots, predecessors = _native_chains(native, stop_times)
    events, serial = [], 0

    def push(instant, priority, kind, item):
        nonlocal serial
        if instant is not None and instant < horizon:
            heapq.heappush(events, (instant, priority, serial, kind, item))
            serial += 1

    for item in sorted(native, key=lambda r: (r.decision_event_time, r.source_time, r.source_index)):
        push(item.decision_event_time, 2, "stopall", item)
        push(stop_times[item.source_index], 0, "stop", item)
    for item in sorted(primary_lows, key=lambda r: (r.decision_event_time, r.source_time,
                                                   r.source_index, -int(r.number), r.cycle_id or "")):
        push(item.decision_event_time, 1, "pl", item)
    behavior_events = [(kind, r) for kind, rows in (("S", s_zones), ("E", e_zones))
                       for r in rows if getattr(r, "direction", "bullish") == "bullish"
                       and getattr(r, "calculation_valid", True)]
    for kind, item in sorted(behavior_events, key=lambda pair: (
            pair[1].decision_event_time,
            -sequence_priority(pair[0], getattr(pair[1], "color" if pair[0] == "S" else "family")),
            pair[1].source_time, pair[1].source_index, pair[0])):
        push(item.decision_event_time, 3, "behavior", (kind, item))

    movements, states, seen_pl, pl_numbers = {}, {}, set(), {}
    current = latest_movement = pl_anchor = None
    epoch_id, pl_start = 0, 0

    def enter(anchor, anchor_kind, instant, behavior=None):
        if anchor.get("entered"):
            return
        anchor["entered"] = True
        item = anchor["item"]
        index = chronology.main_index(instant, clamp=True)
        candle = chronology.candles[index]
        entry, stop = as_decimal(candle.close), as_decimal(item.price)
        if entry <= stop:
            return
        result.phase = "pl" if anchor_kind == "PL" else "stopall"
        kind, source = behavior if behavior is not None else (None, None)
        identity = f"bullish:setup:{anchor_kind}:{item.source_time.isoformat()}:{item.decision_event_time.isoformat()}"
        result.setups.append(SetupAnnotation(identity, anchor_kind, int(item.number),
            int(item.source_index), item.source_time, item.decision_event_time,
            getattr(item, "cycle_id", None), kind,
            int(source.source_index) if source else None, source.source_time if source else None,
            instant, index, candle.timestamp, candle.timestamp + chronology.timeframe,
            entry, stop, entry + Decimal(4)*(entry-stop)))

    def classify(state, status, instant, reason):
        row, scope, movement = state["row"], state["scope"], state["movement"]
        parity = row.number % 2
        if status == "F":
            scope.parity[parity] = "F"
            for other in scope.rows:
                if other.number % 2 == parity:
                    other.status, other.status_event_time = "F", instant
                    other.reason = reason if other is row else "inherited-parity-failure"
            for owner_parity, behavior in scope.behaviors:
                if owner_parity == parity:
                    behavior.status, behavior.status_event_time = "F", instant
            if scope.priority == parity:
                scope.priority = 1-parity if scope.parity[1-parity] == "T" else None
            if all(value == "F" for value in scope.parity.values()) and not scope.break_scheduled:
                scope.break_scheduled = True
                if not row.ignored_prefix and movement.epoch == epoch_id:
                    at = crossing(instant, movement.reference_high, above=True)
                    push(at, 4, "break", (scope, movement))
        else:
            if scope.parity[parity] != "F":
                scope.parity[parity] = "T"
                row.status, row.status_event_time, row.reason = "T", instant, reason
                if scope.priority is None:
                    scope.priority = parity

    def stop(state, instant):
        state["stopped"] = True
        if state["retired"] or state["row"].status == "F":
            return
        classify(state, "F" if state["had_behavior"] else "T", instant,
                 "behavior-then-stop" if state["had_behavior"] else "stop-without-behavior")

    while events:
        instant, _, _, kind, item = heapq.heappop(events)
        if kind == "stop":
            if item.source_index in states:
                stop(states[item.source_index], instant)
        elif kind == "pl-stop":
            if pl_anchor is not None and pl_anchor["item"] is item:
                pl_anchor["stopped"] = True
        elif kind == "break":
            scope, movement = item
            if movement.epoch == epoch_id and not scope.blocked:
                scope.blocked = True
                result.phase = "waiting-for-larger-movement"
                result.breakouts.append(ReferenceBreak(scope.identity, instant,
                    chronology.main_index(instant, clamp=True), movement.reference_high,
                    movement.reference_source_index))
        elif kind == "pl":
            physical = (item.source_index, item.source_time)
            cycle = getattr(item, "cycle_id", None)
            if physical in seen_pl or int(item.number) <= pl_numbers.get(cycle, 0):
                continue
            seen_pl.add(physical)
            pl_numbers[cycle] = int(item.number)
            epoch_id += 1
            pl_start = chronology.main_index(instant, clamp=True)
            pl_anchor = {"item": item, "entered": False, "stopped": False}
            current, latest_movement = None, None
            result.phase = "pl"
            push(crossing(instant, item.price), 0, "pl-stop", item)
        elif kind == "stopall":
            if current is not None and not current["stopped"] and not current["retired"]:
                old_stop = stop_times[current["item"].source_index]
                if old_stop is None or instant < old_stop:
                    classify(current, "T", instant, "successor-before-stop")
                    current["retired"] = True
            root = roots[item.source_index]
            movement = movements.get(root)
            if movement is None:
                prefix = latest_movement.extent if latest_movement is not None else 0
                high, source = main_prices.range_maximum(pl_start,
                    chronology.main_index(instant, clamp=True)+1)
                movement = _Movement(root, epoch_id, prefix, high, source, item.source_time)
                movements[root] = movement
                latest_movement = movement
            movement.extent = max(movement.extent, int(item.number))
            ignored = int(item.number) <= movement.prefix
            scope = movement.scopes.setdefault(ignored,
                _Scope(f"bullish:setup-scope:{movement.source_time.isoformat()}:{'prefix' if ignored else 'candidate'}"))
            row = StopAllAssessment(item.source_index, item.source_time, int(item.number),
                instant, scope.identity, ignored, movement.reference_high,
                movement.reference_source_index, predecessor_source_indexes=predecessors[item.source_index])
            scope.rows.append(row)
            result.assessments.append(row)
            state = {"item": item, "row": row, "scope": scope, "movement": movement,
                     "had_behavior": False, "stopped": False, "retired": False, "entered": False}
            states[item.source_index] = state
            current = state
            if scope.parity[row.number % 2] == "F":
                row.status, row.status_event_time, row.reason = "F", instant, "inherited-parity-failure"
            native_stop = stop_times[item.source_index]
            if native_stop is not None and native_stop <= instant:
                stop(state, instant)
            first = states.get(root)
            if (row.number == 2 and movement.prefix == 0 and first is not None
                    and first["had_behavior"] and first["row"].reason == "behavior-then-stop"
                    and movement.epoch == epoch_id
                    and not scope.blocked and not (pl_anchor and not pl_anchor["entered"])
                    and not state["stopped"]):
                scope.priority = 0
                enter(state, "StopAll", instant)
        else:
            behavior_kind, behavior = item
            pl_entry = False
            if pl_anchor and not pl_anchor["entered"] and not pl_anchor["stopped"]:
                if instant > pl_anchor["item"].decision_event_time:
                    enter(pl_anchor, "PL", instant, item)
                    pl_entry = True
            if current is None or current["stopped"] or current["retired"]:
                continue
            anchor, row, scope = current["item"], current["row"], current["scope"]
            if instant <= anchor.decision_event_time:
                continue
            first_behavior = not current["had_behavior"]
            current["had_behavior"] = True
            record = BehaviorAssessment(behavior_kind, behavior.source_index, behavior.source_time,
                                        instant, anchor.source_index)
            if row.status == "F":
                record.status, record.status_event_time = "F", instant
            result.behaviors.append(record)
            parity = row.number % 2
            scope.behaviors.append((parity, record))
            initial = row.number == 1 and current["movement"].prefix == 0
            allowed = scope.parity[parity] != "F" and (initial or
                (scope.parity[parity] == "T" and scope.priority == parity))
            if (first_behavior and not pl_entry and allowed and not row.ignored_prefix and not scope.blocked
                    and current["movement"].epoch == epoch_id):
                if scope.priority is None:
                    scope.priority = parity
                enter(current, "StopAll", instant, item)
    return result
