import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";

const root = path.resolve(import.meta.dirname, "../..");

const graph = JSON.parse(fs.readFileSync(path.join(root, "docs/graphify/graph.json"), "utf8"));
const ids = new Set(graph.nodes.map((node) => String(node.id)));
const badEndpoints = graph.links.filter((link) => !ids.has(String(link.source)) || !ids.has(String(link.target)));
console.log(JSON.stringify({
  graphNodes: graph.nodes.length,
  graphLinks: graph.links.length,
  graphCommunities: new Set(graph.nodes.map((node) => node.community)).size,
  badGraphEndpoints: badEndpoints.length,
}));

const rawRoot = path.join(root, "data/raw");
const rawFiles = [];
function walk(directory) {
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    const target = path.join(directory, entry.name);
    if (entry.isDirectory()) walk(target);
    else if (entry.isFile() && entry.name.endsWith(".json") && !entry.name.endsWith(".meta.json")) rawFiles.push(target);
  }
}
walk(rawRoot);

for (const file of rawFiles.sort()) {
  const bytes = fs.readFileSync(file);
  const rows = JSON.parse(bytes.toString("utf8"));
  let schemaErrors = 0;
  let numericErrors = 0;
  let ohlcErrors = 0;
  let orderErrors = 0;
  let duplicates = 0;
  const seen = new Set();
  for (let index = 0; index < rows.length; index++) {
    const row = rows[index];
    if (!row || !["time", "open", "high", "low", "close"].every((key) => Object.hasOwn(row, key))) schemaErrors++;
    const values = [row?.time, row?.open, row?.high, row?.low, row?.close];
    if (!values.every(Number.isFinite)) numericErrors++;
    if (Number.isFinite(row?.high) && Number.isFinite(row?.low) && Number.isFinite(row?.open) && Number.isFinite(row?.close) && (row.low > Math.min(row.open, row.close) || row.high < Math.max(row.open, row.close) || row.low > row.high)) ohlcErrors++;
    if (index && Number(row.time) < Number(rows[index - 1].time)) orderErrors++;
    if (seen.has(row.time)) duplicates++; else seen.add(row.time);
  }
  const metaPath = `${file}.meta.json`;
  const meta = JSON.parse(fs.readFileSync(metaPath, "utf8"));
  const sha = crypto.createHash("sha256").update(bytes).digest("hex");
  console.log(JSON.stringify({
    file: path.relative(root, file).replaceAll("\\", "/"),
    rows: rows.length,
    from: rows.at(0)?.time,
    to: rows.at(-1)?.time,
    schemaErrors, numericErrors, ohlcErrors, orderErrors, duplicates,
    sidecarCountMatch: meta.candleCount === rows.length,
    sidecarBytesMatch: meta.dataBytes === bytes.length,
    sidecarShaMatch: meta.dataSha256 === sha,
  }));
}
