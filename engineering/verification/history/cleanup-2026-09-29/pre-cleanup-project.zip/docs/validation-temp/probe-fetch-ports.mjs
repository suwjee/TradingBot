import http from "node:http";

const outcomes = [];
for (let attempt = 0; attempt < 200; attempt++) {
  const server = http.createServer((_request, response) => response.end("ok"));
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  const port = server.address().port;
  try {
    const response = await fetch(`http://127.0.0.1:${port}`);
    outcomes.push({ port, ok: response.ok });
  } catch (error) {
    outcomes.push({ port, ok: false, error: error?.cause?.message || error.message });
  } finally {
    await new Promise((resolve) => server.close(resolve));
  }
}
const failures = outcomes.filter((item) => !item.ok);
console.log(JSON.stringify({ attempts: outcomes.length, failures }, null, 2));
