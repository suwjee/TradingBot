import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import { resolveLocalStatePaths } from '../../../apps/chart/server/local-state-paths.js';

test('default state root is a sibling of the checkout', () => {
  const workspace = path.resolve('example', 'TradingBot');
  const paths = resolveLocalStatePaths(workspace, '');
  assert.equal(paths.root, path.resolve('example', 'TradingBot-Local'));
  assert.equal(paths.raw, path.join(paths.root, 'data', 'raw'));
  assert.equal(paths.secret, path.join(paths.root, 'secret'));
});

test('custom state root controls every persistent storage path', () => {
  const workspace = path.resolve('example', 'TradingBot');
  const custom = path.resolve('state elsewhere');
  const paths = resolveLocalStatePaths(workspace, custom);
  assert.equal(paths.root, custom);
  for (const name of ['raw', 'cache', 'secret', 'tmp']) {
    assert.ok(path.relative(custom, paths[name]).length > 0);
    assert.ok(!path.relative(custom, paths[name]).startsWith('..'));
  }
});

test('state roots inside the checkout are rejected', () => {
  const workspace = path.resolve('example', 'TradingBot');
  for (const target of [workspace, path.join(workspace, 'runtime')]) {
    assert.throws(() => resolveLocalStatePaths(workspace, target), /outside the repository/);
  }
});
