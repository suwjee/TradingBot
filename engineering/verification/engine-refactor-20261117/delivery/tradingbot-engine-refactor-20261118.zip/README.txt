TradingBot source/change bundle
Created: 2026-11-18T09:57:24+03:30

The current workspace already contains these changes. This bundle preserves
the current Engine Python/style/reference source, changed Chart source,
maintained docs, tests and task evidence. File contents under current/ are
byte-identical to the live workspace at packaging time; SHA-256 is in manifest.json.

This is not a published release or an installer. No RAW, user state, sessions,
tokens, credentials, dependency tree or old engine/engine.zip is included.
The old engine/engine.zip remains an unchanged earlier archive in the workspace.

For a separate checkout, review tracked-changes.patch and the deletion list
before copying files. Merely overlaying current/ does not remove retired files.
Do not overwrite unrelated local work. Read FINAL_REPORT.md and its scope limits.

Deleted tracked paths:
apps/chart/src/chart/setup-annotations.js
apps/chart/tests/unit/setup-annotations.test.mjs
engine/pipeline/bullish_setup_engine.py
engine/tests/unit/test_bullish_setup_engine.py
engine/tests/unit/test_live_bullish_setups.py
engine/tests/unit/test_setup_serialization.py
