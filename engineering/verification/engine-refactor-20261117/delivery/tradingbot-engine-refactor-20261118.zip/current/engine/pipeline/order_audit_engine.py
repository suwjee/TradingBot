"""Central physical Order discovery, reuse, provenance, and audit ownership."""

from __future__ import annotations

from bisect import bisect_left, bisect_right
from copy import deepcopy
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal, localcontext
from heapq import heappop, heappush, merge
from types import SimpleNamespace
from typing import Callable, Sequence

from core_utils import as_decimal, order_identity, reaction_identity

ORDER_AUDIT_ENGINE_VERSION = "1.8.2"
ORDER_AUDIT_ENGINE_IMPLEMENTATION_VERSION = "1.9.0"
ORDER_AUDIT_ENGINE_LAST_MODIFIED = "2026-11-18T07:10:09+03:30"


def relabel_primary_causes(causes, labels):
    """Resolve primary aliases by source without changing Order provenance."""
    result = []
    for cause in causes:
        row = deepcopy(cause)
        for name, source in (("parentType", "parentSourceTime"),
                             ("postBehaviorType", "postBehaviorSourceTime"),
                             ("anchorBehaviorType", "anchorBehaviorSourceTime")):
            if str(row.get(name, "")).startswith(("PH", "PL")) and row.get(source) in labels:
                row[name] = labels[row[source]]
        if row not in result:
            result.append(row)
    return result

@dataclass(frozen=True, slots=True)
class PostBehaviorStop:
    behavior_type: str
    behavior_source_index: int
    behavior_source_time: datetime
    event_time: datetime


@dataclass(frozen=True, slots=True)
class OrderBBehaviorAnchor:
    behavior_type: str
    behavior_source_index: int
    behavior_source_time: datetime
    priority: int
    number: int


@dataclass(frozen=True, slots=True)
class OrderBResetLeg:
    post_stop: PostBehaviorStop
    anchor_behavior_type: str
    anchor_behavior_source_index: int
    anchor_behavior_source_time: datetime
    anchor_behavior_extreme: Decimal
    reset_reaction: object
    reset_confirmation_time: datetime
    reset_source_index: int
    reset_broken_level: Decimal
    reset_time: datetime
    leg_boundary: Decimal
    leg_source_index: int
    leg_source_time: datetime
    strict_break_time: datetime
    reaction_number: int
    physical_reaction: object
    physical_confirmation_time: datetime


def dominant_post_behavior_stops(
    chronology: object,
    lifetimes: Sequence[tuple[str, object, datetime | None]],
    priority: Callable[[object], int],
) -> list[PostBehaviorStop]:
    """Select the accepted lifecycle owner of each stopped main candle."""
    # Rank once, using the original position to retain max()'s first-equal
    # winner. The sweep includes both activation and stop endpoints; expired
    # owners are removed only when their end is strictly before the event.
    ranks = [(
        priority(item), int(getattr(item, "number", 0)),
        getattr(item, "source_time"), int(getattr(item, "source_index")),
    ) for _, item, _ in lifetimes]
    ordered_ranks = sorted(range(len(lifetimes)), key=lambda i: (*ranks[i], -i))
    rank_positions = [0] * len(lifetimes)
    for rank, position in enumerate(ordered_ranks):
        rank_positions[position] = rank
    starts = sorted((
        (getattr(item, "trigger_event_time", None)
         or getattr(item, "decision_event_time", None)
         or getattr(item, "source_time")), i,
    ) for i, (_, item, _) in enumerate(lifetimes))
    owners = {}
    active = []
    cursor = 0
    for event in sorted({end for _, _, end in lifetimes if end is not None}):
        while cursor < len(starts) and starts[cursor][0] <= event:
            position = starts[cursor][1]
            heappush(active, (-rank_positions[position], position))
            cursor += 1
        while active:
            position = active[0][1]
            end = lifetimes[position][2]
            if end is None or event <= end:
                owners[event] = lifetimes[position][1]
                break
            heappop(active)
    by_candle: dict[int, tuple[tuple[object, ...], PostBehaviorStop]] = {}
    for behavior_type, behavior, event_time in lifetimes:
        if event_time is None:
            continue
        if owners.get(event_time) is not behavior:
            continue
        source_time = getattr(behavior, "source_time")
        source_index = int(getattr(behavior, "source_index"))
        stop_index = chronology.main_index(event_time, clamp=True)
        rank = (
            priority(behavior), int(getattr(behavior, "number", 0)),
            source_time, source_index, event_time,
        )
        selected = PostBehaviorStop(
            behavior_type, source_index, source_time, event_time,
        )
        previous = by_candle.get(stop_index)
        if previous is None or rank > previous[0]:
            by_candle[stop_index] = rank, selected
    return sorted(
        (item[1] for item in by_candle.values()),
        key=lambda item: (item.event_time, item.behavior_source_index),
    )


def order_b_reset_event_time(
    direction: str, chronology: object, reset: object,
) -> datetime | None:
    """Resolve a main-candle Reset to its first strict selected-RAW crossing."""
    precise = getattr(reset, "second_time", None)
    if precise:
        return chronology.reset_time(reset)
    reset_index = int(getattr(reset, "index"))
    start = chronology.times[reset_index]
    left = bisect_left(chronology.second_times, start)
    right = bisect_left(chronology.second_times, start + chronology.timeframe)
    level = as_decimal(getattr(reset, "broken_level"))
    if chronology.lower_index is not None:
        crossing = (
            chronology.lower_index.first_less(left, right, level)
            if direction == "bullish" else
            chronology.lower_index.first_greater(left, right, level)
        )
    else:
        attribute = "low" if direction == "bullish" else "high"
        crossing = next((
            index for index in range(left, right)
            if (
                as_decimal(getattr(chronology.seconds[index], attribute)) < level
                if direction == "bullish" else
                as_decimal(getattr(chronology.seconds[index], attribute)) > level
            )
        ), None)
    return None if crossing is None else chronology.second_times[crossing]


def _order_b_boundary(chronology, first: int, last: int, attribute: str):
    anchor = as_decimal(getattr(chronology.candles[first], attribute))
    source_index, boundary = first, anchor
    for index in range(first + 1, last + 1):
        value = as_decimal(getattr(chronology.candles[index], attribute))
        if (value < boundary if attribute == "low" else value > boundary):
            boundary, source_index = value, index
    return anchor, boundary, source_index


def _order_b_crossing(chronology, attribute: str, left: int, boundary: Decimal):
    right = len(chronology.second_times)
    if left >= right:
        return None
    index = chronology.lower_index
    if index is not None:
        find = index.first_less if attribute == "low" else index.first_greater
        position = find(left, right, boundary)
    else:
        position = None
        for cursor in range(left, right):
            value = as_decimal(getattr(chronology.seconds[cursor], attribute))
            if (value < boundary if attribute == "low" else value > boundary):
                position = cursor
                break
    return chronology.second_times[position] if position is not None else None


def discover_order_b_reset_legs(
    direction: str,
    chronology: object,
    trend_reactions: Sequence[object],
    resets: Sequence[object],
    opposite_reactions: Sequence[object],
    post_stops: Sequence[PostBehaviorStop],
    a_formation_times: Sequence[datetime],
    *,
    behavior_anchors: Sequence[OrderBBehaviorAnchor] = (),
    _boundary=None,
    _crossing=None,
) -> list[OrderBResetLeg]:
    """Find Order_B from post-stop HH/LL reset-leg geometry.

    The stop event opens eligibility, but the geometric anchor is the latest
    accepted behavior that already exists before the Reset Reaction First
    candle, regardless of whether that behavior is dominant.  Bearish uses
    the highest High from the anchor behavior candle through the Reset
    Reaction FirstGreen; Bullish mirrors it with the lowest Low through
    FirstRed.  The boundary must extend strictly beyond the anchor behavior
    candle and the reset Reaction must start strictly after that boundary
    source.  Order_B selection is owned by the calculation timeframe: the
    first main candle containing a strict post-Reset boundary crossing opens
    the opposite-Reaction gate, and a canonical opposite Reaction whose First
    is that same main candle is eligible.  Lower-timeframe chronology is kept
    only to prove that the crossing occurs after the exact Reset and, when
    needed, that confirmation occurs strictly after the crossing.
    """
    if direction not in {"bullish", "bearish"}:
        raise ValueError("Direction must be 'bullish' or 'bearish'.")
    if not post_stops or not behavior_anchors:
        return []

    lower_times = chronology.second_times
    opposite = chronology.opposite_direction(direction)
    attribute = "low" if direction == "bullish" else "high"
    boundary_at = _boundary or (lambda first, last: _order_b_boundary(chronology, first, last, attribute))
    crossing_after = _crossing or (
        lambda time, level: _order_b_crossing(chronology, attribute, bisect_right(lower_times, time), level)
    )

    same_direction = sorted(
        (
            chronology.reaction_confirmation(direction, reaction),
            int(getattr(reaction, "first_idx")),
            int(getattr(reaction, "break_idx")),
            ordinal,
            reaction,
        )
        for ordinal, reaction in enumerate(trend_reactions)
    )
    same_by_first: dict[int, list[tuple[datetime, int, int, int, object]]] = {}
    for item in same_direction:
        same_by_first.setdefault(item[1], []).append(item)

    opposite_direction = sorted(
        (
            chronology.reaction_confirmation(opposite, reaction),
            int(getattr(reaction, "first_idx")),
            int(getattr(reaction, "break_idx")),
            number,
            reaction,
        )
        for number, reaction in enumerate(opposite_reactions, start=1)
    )
    reset_events = sorted(
        (
            event_time,
            int(getattr(reset, "from_first_idx")), ordinal, reset,
        )
        for ordinal, reset in enumerate(resets)
        if (event_time := order_b_reset_event_time(direction, chronology, reset))
        is not None
    )
    stops = sorted(
        post_stops,
        key=lambda item: (
            item.event_time, item.behavior_source_time,
            item.behavior_source_index, item.behavior_type,
        ),
    )
    stop_times = [item.event_time for item in stops]
    anchors = sorted(
        behavior_anchors,
        key=lambda item: (
            item.behavior_source_time, item.behavior_source_index,
            item.priority, item.number, item.behavior_type,
        ),
    )
    anchor_times = [item.behavior_source_time for item in anchors]
    a_times = sorted(a_formation_times)

    found: list[OrderBResetLeg] = []
    for reset_time, reset_first, _ordinal, reset in reset_events:
        current_candidates = [
            item for item in same_by_first.get(reset_first, ())
            if item[0] < reset_time
        ]
        if not current_candidates:
            continue
        current = current_candidates[-1]
        current_first_time = chronology.times[current[1]]

        stop_position = bisect_left(stop_times, current_first_time) - 1
        if stop_position < 0:
            continue
        post_stop = stops[stop_position]

        anchor_position = bisect_left(anchor_times, current_first_time) - 1
        if anchor_position < 0:
            continue
        anchor = anchors[anchor_position]
        if anchor.behavior_source_index > current[1]:
            continue

        anchor_extreme, boundary, source_index = boundary_at(anchor.behavior_source_index, current[1])

        extends_anchor = (
            boundary < anchor_extreme
            if direction == "bullish" else boundary > anchor_extreme
        )
        if not extends_anchor:
            continue
        # The Reset Reaction itself must occur after the LL/HH source.
        if source_index >= current[1]:
            continue

        strict_break_time = crossing_after(reset_time, boundary)
        if strict_break_time is None:
            continue
        strict_break_index = chronology.main_index(strict_break_time, clamp=True)

        # Order_B is a calculation-timeframe rule.  The exact lower-TF crossing
        # proves the break happened after Reset and remains audit provenance,
        # but it must not disqualify a canonical opposite Reaction whose First
        # belongs to the same calculation candle as that strict break.
        #
        # A newly formed accepted A is likewise compared by its owning main
        # candle.  This keeps lifecycle expiry on the configured calculation
        # timeframe while preserving lower-TF chronology only where exact
        # within-candle ordering is genuinely required.
        next_a_position = bisect_right(a_times, current_first_time)
        if (
            next_a_position < len(a_times)
            and chronology.main_index(a_times[next_a_position], clamp=True)
            <= strict_break_index
        ):
            continue

        physical = next((
            item for item in opposite_direction
            if strict_break_index <= item[1]
            and strict_break_time < item[0]
        ), None)
        if physical is None:
            continue

        found.append(OrderBResetLeg(
            post_stop=post_stop,
            anchor_behavior_type=anchor.behavior_type,
            anchor_behavior_source_index=anchor.behavior_source_index,
            anchor_behavior_source_time=anchor.behavior_source_time,
            anchor_behavior_extreme=anchor_extreme,
            reset_reaction=current[4],
            reset_confirmation_time=current[0],
            reset_source_index=int(getattr(reset, "index")),
            reset_broken_level=as_decimal(getattr(reset, "broken_level")),
            reset_time=reset_time,
            leg_boundary=boundary,
            leg_source_index=source_index,
            leg_source_time=chronology.times[source_index],
            strict_break_time=strict_break_time,
            reaction_number=physical[3],
            physical_reaction=physical[4],
            physical_confirmation_time=physical[0],
        ))
    return found


class LiveOrderBResetLegs:
    """Reuse settled Order_B market geometry and extend pending strict crossings."""

    def __init__(self, direction: str):
        if direction not in {"bullish", "bearish"}:
            raise ValueError("Direction must be 'bullish' or 'bearish'.")
        self._direction = direction
        self._attribute = "low" if direction == "bullish" else "high"
        self._boundaries = {}
        self._crossings = {}
        self._last_lower_time = None

    def update(
        self, chronology, trend_reactions, resets, opposite_reactions, post_stops, a_formation_times,
        *, behavior_anchors, first_dirty_main: int,
    ) -> list[OrderBResetLeg]:
        if not 0 <= first_dirty_main <= len(chronology.times):
            raise ValueError("The changed market index is outside the Order_B chronology.")
        dirty = chronology.times[first_dirty_main] if first_dirty_main < len(chronology.times) else None
        lower_times = chronology.second_times
        last_lower = lower_times[-1] if lower_times else None
        dirty_lower = bisect_left(lower_times, dirty) if dirty is not None else len(lower_times)
        old_limit = (
            bisect_right(lower_times, self._last_lower_time)
            if self._last_lower_time is not None else 0
        )
        boundaries, crossings = {}, {}

        def boundary(first, last):
            key = (first, last)
            cached = boundaries.get(key)
            if cached is None and last < first_dirty_main:
                cached = self._boundaries.get(key)
            if cached is None:
                cached = _order_b_boundary(chronology, first, last, self._attribute)
            boundaries[key] = cached
            return cached

        def crossing(reset_time, level):
            key = (reset_time, level)
            if key in crossings:
                return crossings[key]
            old = self._crossings.get(key)
            if old is not None and (dirty is None or old < dirty) and last_lower is not None and old <= last_lower:
                found = old
            else:
                left = bisect_right(lower_times, reset_time)
                if key in self._crossings:
                    left = max(left, min(old_limit, dirty_lower))
                found = _order_b_crossing(chronology, self._attribute, left, level)
            crossings[key] = found
            return found

        found = discover_order_b_reset_legs(
            self._direction, chronology, trend_reactions, resets, opposite_reactions,
            post_stops, a_formation_times, behavior_anchors=behavior_anchors,
            _boundary=boundary, _crossing=crossing,
        )
        self._boundaries = boundaries
        self._crossings = crossings
        self._last_lower_time = last_lower
        return found


def discover_accepted_order_b_reset_legs(
    direction: str,
    chronology: object,
    trend_reactions: Sequence[object],
    trend_resets: Sequence[object],
    opposite_reactions: Sequence[object],
    a_zones: Sequence[object],
    invalid_a_identities: set[tuple[datetime, int]],
    s_zones: Sequence[object],
    e_zones: Sequence[object],
    stopalls: Sequence[object],
    s_detector: object,
    e_detector: object,
    priority: Callable[[object], int],
    *,
    reset_leg_finder=None,
) -> list[OrderBResetLeg]:
    """Build reset legs from calculation-accepted lifecycle owners."""
    accepted_a = [
        item for item in a_zones
        if (getattr(item, "source_time"), int(getattr(item, "source_index")))
        not in invalid_a_identities
    ]
    lifetimes: list[tuple[str, object, datetime | None]] = []
    for item in accepted_a:
        ordinal = int(getattr(item, "reaction_number"))
        confirmation = chronology.reaction_confirmation(
            direction, trend_reactions[ordinal - 1]
        )
        stopped = s_detector.first_a_stop(
            as_decimal(getattr(item, "price")), confirmation
        )
        lifetimes.append(("A", item, stopped[2] if stopped is not None else None))
    for behavior_type, items in (("S", s_zones), ("E", e_zones)):
        for item in items:
            stopped = e_detector.parent_stop(behavior_type, item)
            lifetimes.append((
                behavior_type, item, stopped[1] if stopped is not None else None
            ))
    lifetimes.extend(
        ("StopAll", item, item.stop_event_time)
        for item in stopalls
    )
    dominant = dominant_post_behavior_stops(chronology, lifetimes, priority)

    anchor_candidates: list[OrderBBehaviorAnchor] = []
    for behavior_type, items in (
        ("A", accepted_a), ("S", s_zones), ("E", e_zones),
        ("StopAll", stopalls),
    ):
        for item in items:
            anchor_candidates.append(OrderBBehaviorAnchor(
                behavior_type=behavior_type,
                behavior_source_index=int(getattr(item, "source_index")),
                behavior_source_time=getattr(item, "source_time"),
                priority=priority(item),
                number=int(getattr(item, "number", 0)),
            ))

    # A single source candle may represent several lifecycle projections
    # (for example A/E/StopAll).  The highest lifecycle priority owns only the
    # tie at that exact source; a later lower-priority behavior still becomes
    # the geometric anchor because the rule is explicitly dominant-neutral.
    anchors_by_source: dict[tuple[datetime, int], OrderBBehaviorAnchor] = {}
    for anchor in anchor_candidates:
        key = (anchor.behavior_source_time, anchor.behavior_source_index)
        previous = anchors_by_source.get(key)
        if previous is None or (anchor.priority, anchor.number, anchor.behavior_type) > (
            previous.priority, previous.number, previous.behavior_type
        ):
            anchors_by_source[key] = anchor

    finder = reset_leg_finder or discover_order_b_reset_legs
    return finder(
        direction, chronology, trend_reactions, trend_resets,
        opposite_reactions, dominant,
        [item.trigger_event_time for item in accepted_a],
        behavior_anchors=tuple(anchors_by_source.values()),
    )


OrderMatch = tuple[
    int, object, datetime, Decimal, int, datetime,
    tuple[int, datetime, datetime] | None, tuple[str, ...],
    datetime | None,
]


def order_b_leg_identity(items: Sequence[object]) -> tuple[object, ...]:
    """Identify every accepted HH/LL Order_B cause across lifecycle passes."""
    return tuple(sorted((
        leg.post_stop.behavior_type,
        leg.post_stop.behavior_source_index,
        leg.post_stop.event_time,
        leg.anchor_behavior_type,
        leg.anchor_behavior_source_index,
        leg.anchor_behavior_source_time,
        leg.anchor_behavior_extreme,
        int(getattr(leg.reset_reaction, "first_idx")),
        int(getattr(leg.reset_reaction, "break_idx")),
        leg.reset_source_index,
        leg.reset_broken_level,
        leg.reset_time,
        leg.leg_boundary,
        leg.leg_source_index,
        leg.strict_break_time,
        int(getattr(leg.physical_reaction, "first_idx")),
        int(getattr(leg.physical_reaction, "break_idx")),
    ) for leg in items))



class OrderAuditEngineMixin:
    """Order methods shared by the accepted E lifecycle detector."""

    def _order_stop(
        self, number: int, reaction: object, context_start: datetime | None = None,
    ) -> tuple[Decimal, int, datetime]:
        del context_start  # Provenance never manufactures a context-only stop.
        if (
            1 <= number <= len(self.opposite_reactions)
            and self.opposite_reactions[number - 1] is reaction
        ):
            cached = self._canonical_order_stop_cache.get(number)
            if cached is not None:
                return cached
            result = self.chronology.canonical_order_stop(
                self.order_direction,
                number,
                reaction,
                self.opposite_reactions,
                start_index=self.start_index,
            )
            self._canonical_order_stop_cache[number] = result
            return result
        return self.chronology.canonical_order_stop(
            self.order_direction,
            number,
            reaction,
            self.opposite_reactions,
            start_index=self.start_index,
        )


    def order_stop(
        self, reaction_number: int, reaction: object
    ) -> tuple[Decimal, int, datetime]:
        """Public audit API for canonical Order stop provenance."""
        return self._order_stop(reaction_number, reaction)


    def _first_healthy_direct_geometry(
        self, start: datetime, allow_bounded_continue: bool = False,
    ) -> tuple[int, object, datetime] | None:
        """Return the first healthy geometry after an A/S/E strict stop.

        A candidate completes normally when the active prior reaction is not
        Reset before its confirmation. If that prior reaction is Reset first,
        the search restarts strictly after the Reset candle and the first
        complete geometry owns the new leg.
        """
        if self.direct_geometry_finder is None:
            return None
        # Geometry needs its complete context candle at or after the exact
        # stop event. A First candle that already opened before the lower-time-
        # frame stop cannot be attributed to that stop.
        search_index = self._main_index(start)
        search_event = start
        restarted = False
        while search_index <= self.end_index:
            candidate = self.direct_geometry_finder(
                self.order_direction, search_index, self.end_index, search_event
            )
            if candidate is None:
                return None
            first = self._reaction_first_time(candidate)
            if (
                first in self.blocked_order_first_times
                and first == self.times[self._main_index(start)]
            ):
                search_index = int(getattr(candidate, "first_idx")) + 1
                search_event = first
                continue
            confirmation = self._confirmation_for(
                candidate, self.order_direction
            )
            owner_position = bisect_right(
                self._opposite_confirmations, search_event
            ) - 1
            prior = (
                self.opposite_reactions[owner_position]
                if owner_position >= 0 else None
            )
            reset_before_confirmation = None
            if prior is not None:
                for reset_time in self._opposite_reset_times_by_first.get(
                    int(getattr(prior, "first_idx")), []
                ):
                    if search_event < reset_time <= confirmation:
                        reset_before_confirmation = reset_time
                        break
            if reset_before_confirmation is not None:
                search_index = self._main_index(reset_before_confirmation)
                search_event = reset_before_confirmation
                restarted = True
                continue

            identity = (
                int(getattr(candidate, "first_idx")),
                int(getattr(candidate, "break_idx")),
            )
            canonical_position = self._opposite_identity_position.get(identity)
            if canonical_position is None:
                # Order_A is a physical Order and may only be created from a
                # canonical valid Reaction. Gate-bounded geometry can remain
                # internal continuation evidence, but it must never bypass
                # Reaction/Reset ownership and become Order_A. Canonical
                # fallback is handled by `_direct_parent_stop_order`.
                return None
            candidate = self.opposite_reactions[canonical_position]
            number = canonical_position + 1
            confirmation = self._opposite_confirmations[canonical_position]
            return number, candidate, confirmation
        return None


    def _trend_leg_direct_order(
        self, start: datetime,
    ) -> tuple[int, object, datetime] | None:
        """Return bounded direct Order_A after a newly confirmed trend leg.

        A stopped E may be followed by a fresh same-direction Reaction before
        the next opposite public Reaction exists.  That trend confirmation
        establishes the new forming-leg boundary.  The first bounded opposite
        geometry after that exact confirmation may own direct Order_A when the
        shared gate resolver proves ``continue``.  This is direct
        parent-stop Order_A provenance.
        """
        if self.direct_geometry_finder is None:
            return None
        position = bisect_right(self._trend_confirmation_times, start)
        while position < len(self._trend_by_confirmation):
            confirmation, first_time, trend = self._trend_by_confirmation[position]
            position += 1
            if first_time <= start:
                continue
            if bool(getattr(trend, "behavior_internal", False)):
                continue
            break_index = int(getattr(trend, "break_idx"))
            candidate = self.direct_geometry_finder(
                self.order_direction, break_index, self.end_index, confirmation
            )
            if candidate is None:
                continue
            if getattr(candidate, "order_gate_decision", None) != "continue":
                continue
            candidate_confirmation = self._confirmation_for(
                candidate, self.order_direction
            )
            if self._reaction_first_time(candidate) <= confirmation:
                continue
            identity = (
                int(getattr(candidate, "first_idx")),
                int(getattr(candidate, "break_idx")),
            )
            canonical_position = self._opposite_identity_position.get(identity)
            if canonical_position is not None:
                return (
                    canonical_position + 1,
                    self.opposite_reactions[canonical_position],
                    self._opposite_confirmations[canonical_position],
                )
            # A bounded geometry that is absent from the canonical opposite
            # Reaction stream is internal evidence only, not an Order_A.
            continue
        return None


    def _direct_parent_stop_order(
        self,
        start: datetime,
        continuous_deadline: datetime | None,
        allow_bounded_continue: bool,
        e_parent: bool = False,
        *, confirmation_after: datetime | None = None,
    ) -> tuple[int, object, datetime] | None:
        """Select the direct parent-stop Order_A."""
        cache_key = (start, continuous_deadline, allow_bounded_continue, e_parent, confirmation_after)
        cached = self._direct_parent_stop_cache.get(cache_key)
        if cached is not None or cache_key in self._direct_parent_stop_cache:
            return cached
        result = self._compute_direct_parent_stop_order(
            start, continuous_deadline, allow_bounded_continue, e_parent,
            confirmation_after=confirmation_after,
        )
        self._direct_parent_stop_cache[cache_key] = result
        return result

    def _compute_direct_parent_stop_order(
        self,
        start: datetime,
        continuous_deadline: datetime | None,
        allow_bounded_continue: bool,
        e_parent: bool = False,
        *, confirmation_after: datetime | None = None,
    ) -> tuple[int, object, datetime] | None:
        gate_time = self.times[self._main_index(start)]
        geometric_direct = self._first_healthy_direct_geometry(
            start, allow_bounded_continue
        )
        if (geometric_direct is not None and confirmation_after is not None
                and geometric_direct[2] <= confirmation_after):
            geometric_direct = None
        direct_position = bisect_left(self._opposite_first_times, gate_time)
        if confirmation_after is not None:
            while (direct_position < len(self.opposite_reactions)
                   and self._opposite_confirmations[direct_position] <= confirmation_after):
                direct_position += 1
        while (
            direct_position < len(self.opposite_reactions)
            and self._opposite_first_times[direct_position]
            in self.blocked_order_first_times
            and self._opposite_first_times[direct_position] == gate_time
        ):
            # The invalid-A First veto remains in force except for a native
            # Order_A consumed by this accepted E stop. Exact A/E simultaneous
            # stop and strict post-stop confirmation are required; inherited
            # unrelated blocks cannot be bypassed by a later E stop.
            if (
                e_parent
                and (start, gate_time) in self.e_parent_order_first_exceptions
                and self._opposite_confirmations[direct_position] > start
            ):
                break
            direct_position += 1

        independent = None
        if direct_position < len(self.opposite_reactions):
            independent = (
                direct_position + 1,
                self.opposite_reactions[direct_position],
                self._opposite_confirmations[direct_position],
            )
        geometric_gate_decision = (
            getattr(geometric_direct[1], "order_gate_decision", None)
            if geometric_direct is not None
            else None
        )
        prefer_geometric = (
            continuous_deadline is not None
            and geometric_direct is not None
            and geometric_gate_decision == "restart"
            and (
                continuous_deadline == self.range_end
                or continuous_deadline < geometric_direct[2]
            )
        )
        independent_cross = None
        if independent is not None:
            independent_level, _, _ = self._order_stop(
                independent[0], independent[1]
            )
            independent_cross = self._cross_order(
                independent[2], independent_level
            )

        direct_pool: list[tuple[int, object, datetime]] = []
        if prefer_geometric:
            direct_pool.append(geometric_direct)
        elif (
            geometric_direct is not None
            and independent_cross is None
            and (
                independent is None
                or self._reaction_first_time(geometric_direct[1])
                < self._reaction_first_time(independent[1])
            )
        ):
            direct_pool.append(geometric_direct)
        elif independent is not None:
            direct_pool.append(independent)

        if not direct_pool:
            return None
        return min(
            direct_pool,
            key=lambda item: (self._reaction_first_time(item[1]), item[2]),
        )


    def _merge_order_candidate(
        self,
        by_geometry: dict[tuple[int, int], OrderMatch],
        number: int,
        reaction: object,
        confirmation: datetime,
        *,
        parent_stop_cause_time: datetime,
    ) -> OrderMatch:
        """Register one parent-stop Order_A candidate by physical identity."""
        level, source, source_time = self._order_stop(number, reaction)
        crossed = self._cross_order(confirmation, level)
        key = reaction_identity(reaction)
        match: OrderMatch = (
            number,
            reaction,
            confirmation,
            level,
            source,
            source_time,
            crossed,
            ("parent-stop",),
            parent_stop_cause_time,
        )
        existing = by_geometry.get(key)
        if existing is None or (
            confirmation, int(getattr(reaction, "first_idx")), int(getattr(reaction, "break_idx"))
        ) < (
            existing[2], int(getattr(existing[1], "first_idx")), int(getattr(existing[1], "break_idx"))
        ):
            by_geometry[key] = match
        return by_geometry[key]


    def _enforce_single_parent_stop_owner(
        self, by_geometry: dict[tuple[int, int], OrderMatch]
    ) -> None:
        """Keep exactly one physical Order_A for one parent-stop event."""
        parent_candidates = [
            item for item in by_geometry.values() if "parent-stop" in item[7]
        ]
        if len(parent_candidates) <= 1:
            return
        owner = min(
            parent_candidates,
            key=lambda item: (
                item[2], int(getattr(item[1], "first_idx")),
                int(getattr(item[1], "break_idx")),
            ),
        )
        owner_identity = reaction_identity(owner[1])
        for identity, item in list(by_geometry.items()):
            if identity == owner_identity or "parent-stop" not in item[7]:
                continue
            remaining = tuple(cause for cause in item[7] if cause != "parent-stop")
            if remaining:
                by_geometry[identity] = (*item[:7], remaining, None)
            else:
                del by_geometry[identity]


    def order_candidates(
        self,
        start: datetime,
        continuous_deadline: datetime | None = None,
        allow_bounded_continue: bool = False,
        allow_trend_leg_continue: bool = False,
        e_parent: bool = False,
    ) -> list[OrderMatch]:
        """Return physical Order candidates formed before this E decision."""
        cache_key = (
            start,
            continuous_deadline,
            allow_bounded_continue,
            allow_trend_leg_continue,
            e_parent,
        )
        cached = self._order_candidates_cache.get(cache_key)
        if cached is not None:
            return list(cached)

        by_geometry: dict[tuple[int, int], OrderMatch] = {}
        direct = self._direct_parent_stop_order(
            start, continuous_deadline, allow_bounded_continue, e_parent
        )
        if direct is not None:
            self._merge_order_candidate(
                by_geometry,
                *direct,
                parent_stop_cause_time=start,
            )

        if allow_trend_leg_continue:
            trend_direct = self._trend_leg_direct_order(start)
            if trend_direct is not None:
                self._merge_order_candidate(
                    by_geometry,
                    *trend_direct,
                    parent_stop_cause_time=start,
                )

        # Reset-leg provenance is independent of the one-Order-per-parent
        # parent-stop rule, but shares the canonical physical identity.
        for leg in self.order_b_legs:
            reaction = leg.physical_reaction
            if self._reaction_first_time(reaction) <= start:
                continue
            identity = reaction_identity(reaction)
            previous = by_geometry.get(identity)
            if previous is not None:
                by_geometry[identity] = (
                    *previous[:7],
                    tuple(dict.fromkeys((*previous[7], "reset-leg"))),
                    previous[8],
                )
                continue
            level, source, source_time = self._order_stop(
                leg.reaction_number, reaction
            )
            by_geometry[identity] = (
                leg.reaction_number, reaction, leg.physical_confirmation_time,
                level, source, source_time,
                self._cross_order(leg.physical_confirmation_time, level),
                ("reset-leg",), None,
            )

        # One exact parent stop may create only one physical Order_A.
        self._enforce_single_parent_stop_owner(by_geometry)

        stopped = [
            item[6][2]
            for item in by_geometry.values()
            if item[6] is not None
        ]
        decision_deadline = min(stopped) if stopped else self.range_end
        if continuous_deadline is not None:
            decision_deadline = min(decision_deadline, continuous_deadline)
        eligible = [
            item for item in by_geometry.values()
            if item[2] <= decision_deadline
        ]
        result = sorted(
            eligible,
            key=lambda item: (
                item[6][2] if item[6] is not None else self.range_end,
                self._reaction_first_time(item[1]),
            ),
        )
        self._order_candidates_cache[cache_key] = tuple(result)
        return result


    def _first_order(
        self, start: datetime, continuous_deadline: datetime | None = None,
        allow_bounded_continue: bool = False,
        allow_trend_leg_continue: bool = False,
    ) -> OrderMatch | None:
        candidates = [
            item for item in self.order_candidates(
                start, continuous_deadline,
                allow_bounded_continue=allow_bounded_continue,
                allow_trend_leg_continue=allow_trend_leg_continue,
            )
            if item[6] is not None
        ]
        return candidates[0] if candidates else None


    def _has_sequence_reset_between(
        self, start: datetime, end: datetime,
    ) -> bool:
        """Return whether a known hard reset lies in ``(start, end]``."""
        position = bisect_right(self._sequence_reset_times, start)
        return (
            position < len(self._sequence_reset_times)
            and self._sequence_reset_times[position] <= end
        )


    def _index_order_audit_identity(
        self, identity: tuple[int, int], confirmation: datetime,
    ) -> None:
        """Index one newly accepted physical Order by confirmation chronology."""
        first_index, break_index = identity
        item = (confirmation, first_index, break_index)
        position = bisect_right(self._order_audit_confirmation_index, item)
        self._order_audit_confirmation_index.insert(position, item)
        self._post_stop_sorted_audit = None


    def _clear_order_audit(self) -> None:
        self.order_audit.clear()
        self._order_audit_confirmation_index.clear()
        self._carried_orders_cache.clear()
        self._carried_creation_index = None
        self._invalidate_post_stop_order_cache()

    def _invalidate_carried_order_caches(self) -> None:
        # Carried results depend on creation causes, so they must drop when a
        # cause is added. Post-stop results depend only on the confirmation
        # index length (included in its cache key), so cause-only mutations
        # must not wipe that cache.
        self._carried_orders_cache.clear()
        self._carried_creation_index = None

    def _invalidate_post_stop_order_cache(self) -> None:
        self._post_stop_orders_cache.clear()
        self._post_stop_sorted_audit = None


    def register_order_b_reset_legs(
        self, legs: Sequence[OrderBResetLeg],
    ) -> None:
        """Merge proven reset-leg causes by canonical physical identity."""
        if legs:
            self._invalidate_carried_order_caches()
        for leg in legs:
            reaction = leg.physical_reaction
            identity = reaction_identity(reaction)
            entry = self.order_audit.get(identity)
            if entry is None:
                level, source, source_time = self._order_stop(
                    leg.reaction_number, reaction
                )
                entry = {
                    "reaction_number": leg.reaction_number,
                    "reaction": reaction,
                    "confirmation_time": leg.physical_confirmation_time,
                    "stop_level": level,
                    "stop_source_index": source,
                    "stop_source_time": source_time,
                    "stop_cross": self._cross_order(
                        leg.physical_confirmation_time, level
                    ),
                    "causes": set(),
                }
                self.order_audit[identity] = entry
                self._index_order_audit_identity(
                    identity, leg.physical_confirmation_time
                )
            current = leg.reset_reaction
            cause = {
                "kind": "reset-leg",
                "postBehaviorType": leg.post_stop.behavior_type,
                "postBehaviorStopTime": leg.post_stop.event_time,
                "postBehaviorSourceIndex": leg.post_stop.behavior_source_index,
                "postBehaviorSourceTime": leg.post_stop.behavior_source_time,
                "anchorBehaviorType": leg.anchor_behavior_type,
                "anchorBehaviorSourceIndex": leg.anchor_behavior_source_index,
                "anchorBehaviorSourceTime": leg.anchor_behavior_source_time,
                "anchorBehaviorExtreme": str(leg.anchor_behavior_extreme),
                "resetReactionIdentity": [
                    int(getattr(current, "first_idx")),
                    int(getattr(current, "break_idx")),
                ],
                "resetReactionBreakoutTime": self.times[int(getattr(current, "break_idx"))],
                "resetReactionConfirmationTime": leg.reset_confirmation_time,
                "resetIndex": leg.reset_source_index,
                "resetBrokenLevel": str(leg.reset_broken_level),
                "resetTime": leg.reset_time,
                "legBoundary": str(leg.leg_boundary),
                "legBoundarySourceIndex": leg.leg_source_index,
                "legBoundarySourceTime": leg.leg_source_time,
                "strictBreakTime": leg.strict_break_time,
                "physicalOrderIdentity": [identity[0], identity[1]],
                "physicalOrderConfirmationTime": leg.physical_confirmation_time,
            }
            causes = entry.setdefault("order_b_causes", [])
            if cause not in causes:
                causes.append(cause)
                causes.sort(key=lambda item: (
                    item["postBehaviorStopTime"], item["resetTime"],
                    item["strictBreakTime"], item["physicalOrderIdentity"],
                ))
                self._invalidate_carried_order_caches()


    def _reparent_primary_high_causes(self, parent, stop_event, direct_identity):
        """Replace only StopAll roles owned by a confirmed primary point."""
        label = f"{parent.kind}{parent.number}"
        source = (int(parent.source_index), parent.source_time)
        changed = False
        revoked = set()
        for identity, entry in self.order_audit.items():
            previous = entry.get("causes", set())
            current = set()
            for cause in previous:
                replaced = (cause[0] == "parent-stop" and str(cause[1]).startswith("StopAll")
                    and cause[4] == parent.source_time and stop_event is not None
                    and cause[3] == stop_event and cause[3] > parent.decision_event_time)
                if not replaced:
                    current.add(cause)
                elif identity == direct_identity:
                    current.add((cause[0], label, "", cause[3], cause[4]))
            if current != previous:
                entry["causes"] = current
                changed = True
            for cause in entry.get("order_b_causes", ()):
                if (str(cause.get("postBehaviorType", "")).startswith("StopAll")
                        and (cause.get("postBehaviorSourceIndex"), cause.get("postBehaviorSourceTime")) == source
                        and stop_event is not None
                        and cause.get("postBehaviorStopTime") == stop_event
                        and stop_event > parent.decision_event_time):
                    cause["postBehaviorType"] = label
                    changed = True
                reset_identity = cause.get("resetReactionIdentity")
                if (str(cause.get("anchorBehaviorType", "")).startswith("StopAll")
                        and (cause.get("anchorBehaviorSourceIndex"), cause.get("anchorBehaviorSourceTime")) == source
                        and reset_identity
                        and self.times[int(reset_identity[0])] >= parent.decision_event_time):
                    cause["anchorBehaviorType"] = label
                    changed = True
            if not current and not entry.get("order_b_causes"):
                revoked.add(identity)
        for identity in revoked:
            del self.order_audit[identity]
        if revoked:
            self._order_audit_confirmation_index[:] = [
                item for item in self._order_audit_confirmation_index
                if (item[1], item[2]) not in revoked
            ]
            self._invalidate_post_stop_order_cache()
        if changed or revoked:
            self._invalidate_carried_order_caches()

    def register_primary_high(self, parent):
        """Create the native bearish-owner Order_A after a confirmed PH stop.

        PH replaces the final StopAll owner without deleting the historical
        sequence boundaries that were needed before PH confirmation.
        """
        if self.direction != "bearish" or getattr(parent, "kind", None) != "PH":
            raise ValueError("Primary-High Order_A is specified for the bearish owner only.")
        return self._register_primary_point(parent)

    def register_primary_low(self, parent):
        """Create native bullish-owner Order_A after a confirmed PL stop."""
        if self.direction != "bullish" or getattr(parent, "kind", None) != "PL":
            raise ValueError("Primary-Low Order_A is specified for the bullish owner only.")
        return self._register_primary_point(parent)

    def _primary_parent_order(self, parent):
        left = bisect_right(self.lower_times, parent.decision_event_time)
        right = bisect_left(self.lower_times, self.range_end)
        position = self._first_cross_position(left, right, as_decimal(parent.price),
                                              less=self.direction == "bullish")
        stop_event = self.lower_times[position] if position is not None else None
        direct = self._direct_parent_stop_order(
            stop_event, None, False, confirmation_after=stop_event,
        ) if stop_event is not None else None
        return stop_event, direct

    def primary_order_dependency(self, parent):
        """Describe the current market inputs of one primary Order registration."""
        stop, direct = self._primary_parent_order(parent)
        if direct is None:
            return stop, None
        number, reaction, confirmation = direct
        level, source, source_time = self._order_stop(number, reaction)
        return stop, repr(direct), str(level), source, source_time, self._cross_order(confirmation, level)

    def _register_primary_point(self, parent):
        stop_event, direct = self._primary_parent_order(parent)
        self._reparent_primary_high_causes(
            parent, stop_event, reaction_identity(direct[1]) if direct is not None else None,
        )
        if direct is None:
            return None
        number, reaction, confirmation = direct
        identity = reaction_identity(reaction)
        entry = self.order_audit.get(identity)
        if entry is None:
            level, source, source_time = self._order_stop(number, reaction)
            entry = {
                "reaction_number": number, "reaction": reaction,
                "confirmation_time": confirmation, "stop_level": level,
                "stop_source_index": source, "stop_source_time": source_time,
                "stop_cross": self._cross_order(confirmation, level), "causes": set(),
            }
            self.order_audit[identity] = entry
            self._index_order_audit_identity(identity, confirmation)
        cause = ("parent-stop", f"{parent.kind}{parent.number}", "", stop_event, parent.source_time)
        if cause not in entry["causes"]:
            entry["causes"].add(cause)
            self._invalidate_carried_order_caches()
        return identity

    def reconcile_primary_high_labels(self, highs):
        """Publish one final PH name without rediscovering or moving Orders."""
        self._reconcile_primary_labels(highs, "PH")

    def reconcile_primary_low_labels(self, lows):
        """Publish one final PL name without rediscovering or moving Orders."""
        self._reconcile_primary_labels(lows, "PL")

    def _reconcile_primary_labels(self, points, prefix):
        labels = {point.source_time: f"{prefix}{point.number}" for point in points}
        changed = False
        for entry in self.order_audit.values():
            previous = entry.get("causes", set())
            current = {(kind, labels.get(source, label) if str(label).startswith(prefix) else label,
                        family, event, source)
                       for kind, label, family, event, source in previous}
            if current != previous:
                entry["causes"] = current
                changed = True
            previous_b = entry.get("order_b_causes", [])
            current_b = relabel_primary_causes(previous_b, labels)
            if current_b != previous_b:
                entry["order_b_causes"] = current_b
                changed = True
        if changed:
            self._invalidate_carried_order_caches()

    def _register_order_audit(
        self, parent_type: str, parent: object, parent_stop: datetime,
    ) -> None:
        """Register only the physical Order_A created by this parent stop."""
        if parent_type == "S":
            source_identity = (parent.source_time, int(parent.source_index))
            if (source_identity in self.invalid_s_root_identities
                    or source_identity in self._accepted_e_source_identities):
                return
        if self._has_sequence_reset_between(parent.source_time, parent_stop):
            return
        matches = self.order_candidates(
            parent_stop,
            None,
            allow_bounded_continue=(parent_type == "S"),
            allow_trend_leg_continue=(parent_type == "E"),
            e_parent=(parent_type == "E"),
        )
        direct = self._direct_parent_stop_order(
            parent_stop, None, allow_bounded_continue=(parent_type == "S"),
            e_parent=(parent_type == "E"),
        )
        if direct is not None:
            direct_identity = reaction_identity(direct[1])
            if all(reaction_identity(item[1]) != direct_identity for item in matches):
                level, source, source_time = self._order_stop(direct[0], direct[1])
                matches.append((
                    direct[0], direct[1], direct[2], level, source, source_time,
                    self._cross_order(direct[2], level), ("parent-stop",),
                    parent_stop,
                ))

        creation_changed = False
        for match in matches:
            number, reaction, confirmation, level, source, source_time = match[:6]
            crossed, causes = match[6], match[7]
            if "parent-stop" not in causes:
                continue
            key = reaction_identity(reaction)
            entry = self.order_audit.get(key)
            if entry is None:
                entry = {
                    "reaction_number": number,
                    "reaction": reaction,
                    "confirmation_time": confirmation,
                    "stop_level": level,
                    "stop_source_index": source,
                    "stop_source_time": source_time,
                    "stop_cross": crossed,
                    "causes": set(),
                }
                self.order_audit[key] = entry
                self._index_order_audit_identity(key, confirmation)
                creation_changed = True
            audit_causes = entry["causes"]
            assert isinstance(audit_causes, set)
            family = str(getattr(parent, "color", getattr(parent, "family", "")))
            number_value = getattr(parent, "number", None)
            parent_label = parent_type
            if parent_type == "E" and number_value is not None:
                parent_label = f"E{number_value}"
            if parent.source_time in self.sequence_resets:
                parent_label = f"StopAll{self.sequence_resets[parent.source_time]}"
                family = ""
            cause = (
                "parent-stop", parent_label, family, parent_stop,
                getattr(parent, "source_time"),
            )
            if cause not in audit_causes:
                try:
                    previous_creation = min((item[3] for item in audit_causes if item[0] == "parent-stop"), default=None)
                    earlier_creation = previous_creation is None or parent_stop < previous_creation
                except Exception:
                    # Non-native provenance retains the former conservative
                    # invalidation without introducing a registration error.
                    earlier_creation = True
                audit_causes.add(cause)
                # Carried eligibility uses only the earliest parent creation,
                # plus every B confirmation. Later/equal parent provenance
                # remains in the ledger but cannot change this query's result.
                if earlier_creation:
                    creation_changed = True
        if creation_changed:
            self._invalidate_carried_order_caches()


    @staticmethod
    def visual_order_lifecycle(
        self, start: datetime,
    ) -> list[tuple[int, object, datetime, Decimal, int, datetime,
                    tuple[int, datetime, datetime] | None, bool]]:
        """Return the first parent-stop Order_A lifecycle after ``start``."""
        position = bisect_left(self._opposite_first_times, start)
        for order_position in range(position, len(self.opposite_reactions)):
            reaction = self.opposite_reactions[order_position]
            first = self._opposite_first_times[order_position]
            confirmation = self._opposite_confirmations[order_position]
            if first < start or confirmation < start:
                continue
            number = order_position + 1
            level, source, source_time = self._order_stop(number, reaction)
            crossed = self._cross_order(confirmation, level)
            return [(
                number, reaction, confirmation, level, source, source_time,
                crossed, False,
            )]
        return []


    def _cross_order(
        self, start: datetime, level: Decimal
    ) -> tuple[int, datetime, datetime] | None:
        cache_key = (start, level)
        if cache_key in self._cross_order_cache:
            return self._cross_order_cache[cache_key]
        left = bisect_left(self.lower_times, max(start, self.range_start))
        right = bisect_left(self.lower_times, self.range_end)
        position = self._first_cross_position(
            left, right, level, less=self.order_direction != "bearish"
        )
        if position is None:
            self._cross_order_cache[cache_key] = None
            return None
        event = self.lower_times[position]
        index = self._main_index(event)
        result = index, getattr(self.candles[index], "timestamp"), event
        self._cross_order_cache[cache_key] = result
        return result


    def cross_order(
        self, confirmation_time: datetime, stop_level: Decimal
    ) -> tuple[int, datetime, datetime] | None:
        """Public audit API for an Order stop crossing."""
        return self._cross_order(confirmation_time, stop_level)


    def _unconsumed_s_orders(
        self, parent: object, parent_stop: datetime
    ) -> list[OrderMatch]:
        """Return the carried A-owned Order whose stop did not decide S."""
        if (
            str(getattr(parent, "color")) != "blue"
            or getattr(parent, "order_confirmation_time", None) is None
            or getattr(parent, "order_stop_level", None) is None
        ):
            return []
        confirmation = getattr(parent, "order_confirmation_time")
        stop_level = as_decimal(getattr(parent, "order_stop_level"))
        crossed = self._cross_order(confirmation, stop_level)
        if crossed is None or crossed[2] < parent_stop:
            return []
        reaction = SimpleNamespace(
            mode=getattr(parent, "order_mode"),
            first_idx=getattr(parent, "order_first_index"),
            break_idx=getattr(parent, "order_break_index"),
            box_top=getattr(parent, "order_box_top"),
            box_top_source_idx=getattr(parent, "order_box_top_source_index"),
            box_bottom=getattr(parent, "order_box_bottom"),
            box_bottom_source_idx=getattr(parent, "order_box_bottom_source_index"),
        )
        return [(
            int(getattr(parent, "order_reaction_number")),
            reaction,
            confirmation,
            stop_level,
            int(getattr(parent, "order_stop_source_index")),
            getattr(parent, "order_stop_source_time"),
            crossed,
            ("carried-live",),
            None,
        )]


    def _initial_order_records(self) -> tuple[tuple[
        datetime, datetime, int, object, Decimal, int, datetime,
        tuple[int, datetime, datetime] | None,
    ], ...]:
        """Materialize immutable initial OrderAudit geometry once per run.

        Algorithm requirement: physical Order identity and exact strict stop
        chronology remain unchanged. Performance detail: the prior code
        recomputed ``_cross_order`` while rescanning this immutable ledger for
        every E parent. The precomputed records only remove repeated pure work.
        """
        cached = self._initial_order_records_cache
        if cached is not None:
            return cached

        records: list[tuple[
            datetime, datetime, int, object, Decimal, int, datetime,
            tuple[int, datetime, datetime] | None,
        ]] = []
        for entry in self.initial_order_audit.values():
            reaction = entry["reaction"]
            first = self._reaction_first_time(reaction)
            confirmation = entry["confirmation_time"]
            level = as_decimal(entry["stop_level"])
            crossed = self._cross_order(confirmation, level)
            records.append((
                first, confirmation, int(entry["reaction_number"]), reaction,
                level, int(entry["stop_source_index"]),
                entry["stop_source_time"], crossed,
            ))

        records.sort(key=lambda item: (item[0], item[1], int(getattr(item[3], "first_idx")), int(getattr(item[3], "break_idx"))))
        cached = tuple(records)
        self._initial_order_records_cache = cached
        self._initial_order_first_times = [item[0] for item in cached]

        by_first: dict[datetime, list[tuple[
            datetime, datetime, int, object, Decimal, int, datetime,
            tuple[int, datetime, datetime] | None,
        ]]] = {}
        for item in cached:
            by_first.setdefault(item[0], []).append(item)
        self._initial_orders_by_first_time = {
            key: tuple(value) for key, value in by_first.items()
        }

        # A separate confirmation-sorted view supports the post-stop route.
        # The record objects are reused; no duplicate Order representation is
        # constructed.
        confirmation_sorted = sorted(
            cached,
            key=lambda item: (item[1], item[0], int(getattr(item[3], "first_idx")), int(getattr(item[3], "break_idx"))),
        )
        self._initial_order_confirmation_records = tuple(confirmation_sorted)
        self._initial_order_confirmation_times = [item[1] for item in confirmation_sorted]
        return cached


    @staticmethod
    def _initial_record_match(
        record: tuple[
            datetime, datetime, int, object, Decimal, int, datetime,
            tuple[int, datetime, datetime] | None,
        ],
        causes: tuple[str, ...],
    ) -> OrderMatch:
        _first, confirmation, number, reaction, level, source_index, source_time, crossed = record
        return (
            number, reaction, confirmation, level, source_index, source_time,
            crossed, causes, None,
        )


    def _initial_order_match(
        self, entry: dict[str, object], causes: tuple[str, ...],
    ) -> OrderMatch:
        """Return one immutable A-owned Order_A audit entry as an OrderMatch."""
        reaction = entry["reaction"]
        confirmation = entry["confirmation_time"]
        level = as_decimal(entry["stop_level"])
        crossed = self._cross_order(confirmation, level)
        return (
            int(entry["reaction_number"]), reaction, confirmation, level,
            int(entry["stop_source_index"]), entry["stop_source_time"],
            crossed, causes, None,
        )


    def _gate_owned_initial_order(
        self, parent_stop: datetime,
    ) -> OrderMatch | None:
        """Keep an A-owned order that starts in the parent-stop candle."""
        gate_time = self.times[self._main_index(parent_stop)]
        self._initial_order_records()
        assert self._initial_orders_by_first_time is not None
        matches: list[OrderMatch] = []
        for record in self._initial_orders_by_first_time.get(gate_time, ()):
            confirmation = record[1]
            if confirmation < parent_stop:
                continue
            crossed = record[7]
            if crossed is None or crossed[2] < parent_stop:
                continue
            matches.append(self._initial_record_match(record, ("carried-live",)))
        return min(
            matches,
            key=lambda item: (item[6][2], self._reaction_first_time(item[1])),
            default=None,
        )


    @staticmethod
    def _carried_creation_events(entry: dict[str, object]) -> list[datetime]:
        created = [cause[3] for cause in entry.get("causes", ()) if cause[0] == "parent-stop"]
        if len(created) > 1:
            created = [min(created)]
        for cause in entry.get("order_b_causes", ()):
            created.append(cause["physicalOrderConfirmationTime"])
        return created

    def _validated_carried_creation_index(self, entries):
        """Index complete native rows; retain legacy evaluation for other rows."""
        events = []
        event_timezone = None
        have_timezone = False
        try:
            # Validation must not set the caller's Decimal flags or change its
            # traps when an unselected malformed price needs the legacy path.
            with localcontext():
                for ordinal, entry in enumerate(entries):
                    if type(entry) is not dict:
                        return None
                    causes = entry.get("causes", ())
                    b_causes = entry.get("order_b_causes", ())
                    if type(causes) not in (set, frozenset, tuple, list) or type(b_causes) not in (tuple, list):
                        return None
                    if any(type(cause) is not tuple or not cause for cause in causes):
                        return None
                    if any(type(cause) is not dict for cause in b_causes):
                        return None
                    created = OrderAuditEngineMixin._carried_creation_events(entry)
                    if not created:
                        continue
                    confirmation = entry["confirmation_time"]
                    crossed = entry.get("stop_cross")
                    dates = (created, (confirmation, entry["stop_source_time"]))
                    if crossed is not None:
                        if type(crossed) is not tuple or len(crossed) < 3 or type(crossed[0]) is not int:
                            return None
                        dates += (crossed[1:3],)
                    for group in dates:
                        for event in group:
                            if type(event) is not datetime:
                                return None
                            if have_timezone and event.tzinfo is not event_timezone:
                                return None
                            event_timezone = event.tzinfo
                            have_timezone = True
                    reaction = entry["reaction"]
                    if any(type(value) is not int for value in (
                        entry["reaction_number"], entry["stop_source_index"],
                        getattr(reaction, "first_idx"), getattr(reaction, "break_idx"),
                    )):
                        return None
                    if type(entry["stop_level"]) not in (Decimal, str, int, float):
                        return None
                    if not as_decimal(entry["stop_level"]).is_finite():
                        return None
                    events.extend((event, ordinal) for event in set(created))
                events.sort()
        except Exception:
            # The original scan owns exception order and short-circuiting.
            return None
        return events, event_timezone

    def _carried_orders_for_parent(
        self, parent: object, parent_stop: datetime,
    ) -> list[OrderMatch]:
        """Return accepted Order identities created and left live in this lifecycle."""
        lifecycle_start = getattr(parent, "decision_event_time", None)
        if lifecycle_start is None:
            return []
        key = lifecycle_start, parent_stop
        cached = self._carried_orders_cache.get(key)
        if cached is not None:
            return list(cached)
        indexed = getattr(self, "_carried_creation_index", None)
        if indexed is None or not self._carried_orders_cache:
            entries = list(self.order_audit.values())
            indexed = self._carried_creation_index = entries, OrderAuditEngineMixin._validated_carried_creation_index(self, entries)
        entries, creation_index = indexed
        use_index = creation_index is not None and all(
            type(event) is datetime and event.tzinfo is creation_index[1]
            for event in (lifecycle_start, parent_stop)
        )
        if use_index:
            events = creation_index[0]
            left = bisect_right(events, (lifecycle_start, len(entries)))
            right = bisect_left(events, (parent_stop, -1))
            # Ledger insertion order remains the stable tie order before
            # sorting. Multiple creation causes select one entry once.
            ordinals = sorted({ordinal for _, ordinal in events[left:right]})
            selected = ((entries[ordinal], None) for ordinal in ordinals)
        else:
            selected = ((entry, OrderAuditEngineMixin._carried_creation_events(entry)) for entry in entries)
        matches: list[OrderMatch] = []
        for entry, created_events in selected:
            if created_events is not None and not created_events:
                continue
            confirmation = entry["confirmation_time"]
            crossed = entry.get("stop_cross")
            if (
                (created_events is not None and not any(
                    lifecycle_start < created < parent_stop for created in created_events
                ))
                or confirmation > parent_stop
                or crossed is None
                or crossed[2] < parent_stop
            ):
                continue
            reaction = entry["reaction"]
            matches.append((
                int(entry["reaction_number"]), reaction, confirmation,
                as_decimal(entry["stop_level"]), int(entry["stop_source_index"]),
                entry["stop_source_time"], crossed, ("carried-live",), None,
            ))

        records = self._initial_order_records()
        assert self._initial_order_first_times is not None
        left = bisect_left(self._initial_order_first_times, lifecycle_start)
        right = bisect_right(self._initial_order_first_times, parent_stop)
        for record in records[left:right]:
            confirmation = record[1]
            if confirmation > parent_stop:
                continue
            crossed = record[7]
            if crossed is None or crossed[2] < parent_stop:
                continue
            matches.append(self._initial_record_match(record, ("carried-live",)))
        result = sorted(
            matches,
            key=lambda item: (item[6][2], -int(getattr(item[1], "first_idx"))),
        )
        self._carried_orders_cache[key] = tuple(result)
        return result


    def _post_stop_accepted_orders_for_parent(
        self, parent: object, parent_stop: datetime,
    ) -> list[OrderMatch]:
        """Return accepted physical Orders confirmed after this parent stop."""
        del parent
        # Safe cache key: confirmation-index length changes whenever a new
        # accepted Order enters the live ledger. Cause-only mutations do not
        # change the post-stop result set.
        cache_key = (parent_stop, len(self._order_audit_confirmation_index))
        cached = self._post_stop_orders_cache.get(cache_key)
        if cached is not None:
            return list(cached)
        matches_by_identity: dict[tuple[int, int], OrderMatch] = {}

        def add_match(match: OrderMatch) -> None:
            crossed = match[6]
            if crossed is None:
                return
            crossed_time = crossed[2]
            if crossed_time <= parent_stop or crossed_time <= match[2]:
                return
            if self._has_sequence_reset_between(parent_stop, crossed_time):
                return
            reaction = match[1]
            identity = (int(getattr(reaction, "first_idx")), int(getattr(reaction, "break_idx")))
            current = matches_by_identity.get(identity)
            if current is None or (
                crossed_time, match[2], int(getattr(reaction, "first_idx"))
            ) < (
                current[6][2], current[2], int(getattr(current[1], "first_idx"))
            ):
                matches_by_identity[identity] = match

        self._initial_order_records()
        assert self._initial_order_confirmation_times is not None
        confirmation_records = self._initial_order_confirmation_records
        start = bisect_right(self._initial_order_confirmation_times, parent_stop)
        for record in confirmation_records[start:]:
            add_match(self._initial_record_match(record, ("accepted-live",)))

        audit_position = bisect_right(
            self._order_audit_confirmation_index,
            (parent_stop, 2**63 - 1, 2**63 - 1),
        )
        for _confirmation, first_index, break_index in (
            self._order_audit_confirmation_index[audit_position:]
        ):
            entry = self.order_audit.get((first_index, break_index))
            if entry is None:
                continue
            reaction = entry.get("reaction")
            confirmation = entry.get("confirmation_time")
            if reaction is None or not isinstance(confirmation, datetime):
                continue
            level_value = entry.get("stop_level")
            source_index = entry.get("stop_source_index")
            source_time = entry.get("stop_source_time")
            if level_value is None or source_index is None or source_time is None:
                continue
            crossed = entry.get("stop_cross")
            if not (
                isinstance(crossed, tuple)
                and len(crossed) >= 3
                and isinstance(crossed[2], datetime)
            ):
                crossed = self._cross_order(confirmation, as_decimal(level_value))
            add_match((
                int(entry.get("reaction_number", 0)), reaction, confirmation,
                as_decimal(level_value), int(source_index), source_time, crossed,
                ("accepted-live",), None,
            ))

        result = sorted(
            matches_by_identity.values(),
            key=lambda item: (
                item[6][2], item[2], -int(getattr(item[1], "first_idx")),
            ),
        )
        self._post_stop_orders_cache[cache_key] = result
        return list(result)

    def _iter_post_stop_accepted_orders(self, parent, parent_stop):
        """Yield accepted Orders in the existing exact order, only as consumed.

        Geometry indexes are subordinate to the accepted ledger. New physical
        identities invalidate the audit view; cause-only edits cannot change
        this use route. Hard-reset eligibility is evaluated at query time.
        """
        key = lambda item: (item[6][2], item[2], -int(getattr(item[1], "first_idx")))
        native_timezone = self.range_start.tzinfo

        def native_time(value):
            return type(value) is datetime and value.tzinfo is native_timezone

        def native_match(match):
            return (
                all(type(value) is int for value in (
                    match[0], match[4], getattr(match[1], "first_idx"), getattr(match[1], "break_idx"),
                ))
                and native_time(match[2]) and native_time(match[5])
                and type(match[3]) is Decimal and match[3].is_finite()
                and (match[6] is None or (
                    type(match[6]) is tuple and len(match[6]) >= 3
                    and type(match[6][0]) is int
                    and native_time(match[6][1]) and native_time(match[6][2])
                ))
            )

        if not native_time(parent_stop):
            return iter(self._post_stop_accepted_orders_for_parent(parent, parent_stop))
        initial = getattr(self, "_post_stop_sorted_initial", None)
        if initial is None:
            # The original query materializes initial geometry before reading
            # the accepted ledger. Retain that eager exception precedence.
            records = self._initial_order_records()
            try:
                with localcontext():
                    matches = [self._initial_record_match(record, ("accepted-live",)) for record in records]
                    if not all(native_match(match) for match in matches):
                        raise ValueError("Non-native initial Order geometry.")
                    initial = sorted((match for match in matches
                                      if match[6] is not None and match[6][2] > match[2]), key=key)
                    initial = initial, [item[6][2] for item in initial]
            except Exception:
                initial = False
            self._post_stop_sorted_initial = initial
        if initial is False:
            return iter(self._post_stop_accepted_orders_for_parent(parent, parent_stop))
        audit = getattr(self, "_post_stop_sorted_audit", None)
        if audit is None:
            try:
                # Validate once per ledger generation without leaking Decimal
                # flags. Partial/malformed rows use the complete query, whose
                # confirmation filter and short-circuit order are contractual.
                with localcontext():
                    matches = []
                    initial_geometry = {}
                    for match in initial[0]:
                        identity = reaction_identity(match[1])
                        geometry = match[6][2], match[2]
                        if initial_geometry.setdefault(identity, geometry) != geometry:
                            raise ValueError("Conflicting initial Order geometry.")
                    for indexed_confirmation, first, last in self._order_audit_confirmation_index:
                        if not native_time(indexed_confirmation) or type(first) is not int or type(last) is not int:
                            raise ValueError("Non-native confirmation index.")
                        entry = self.order_audit.get((first, last))
                        if type(entry) is not dict:
                            raise ValueError("Non-native accepted Order row.")
                        level = entry["stop_level"]
                        if type(level) not in (Decimal, str, int, float):
                            raise ValueError("Non-native accepted Order price.")
                        level = as_decimal(level)
                        match = (entry["reaction_number"], entry["reaction"], entry["confirmation_time"],
                                 level, entry["stop_source_index"], entry["stop_source_time"],
                                 entry.get("stop_cross"), ("accepted-live",), None)
                        if not native_match(match) or indexed_confirmation != match[2]:
                            raise ValueError("Non-native accepted Order geometry.")
                        if match[6] is None:
                            cross_key = match[2], level
                            if cross_key not in self._cross_order_cache or self._cross_order_cache[cross_key] is not None:
                                raise ValueError("Unresolved accepted Order crossing.")
                        elif match[6][2] > match[2]:
                            previous = initial_geometry.get(reaction_identity(match[1]))
                            if previous is not None and previous != (match[6][2], match[2]):
                                # The eager identity dictionary keeps initial
                                # insertion rank after a better audit replacement.
                                # A stream merge cannot infer that query-specific
                                # rank from the winning audit row alone.
                                raise ValueError("Conflicting accepted Order geometry.")
                            matches.append(match)
                    audit = sorted(matches, key=key)
                    audit = audit, [item[6][2] for item in audit]
            except Exception:
                audit = False
            self._post_stop_sorted_audit = audit
        if audit is False:
            return iter(self._post_stop_accepted_orders_for_parent(parent, parent_stop))
        initial, initial_times = initial
        audit, audit_times = audit
        reset_position = bisect_right(self._sequence_reset_times, parent_stop)
        reset = self._sequence_reset_times[reset_position] if reset_position < len(self._sequence_reset_times) else None

        def eligible(items, times):
            for position in range(bisect_right(times, parent_stop), len(items)):
                item = items[position]
                if reset is not None and item[6][2] >= reset:
                    break
                if item[2] > parent_stop:
                    yield item

        def accepted():
            seen = set()
            for match in merge(eligible(initial, initial_times), eligible(audit, audit_times), key=key):
                identity = reaction_identity(match[1])
                if identity not in seen:
                    seen.add(identity)
                    yield match

        return accepted()


    def _order_created_only_by_disowned_s(
        self, identity: tuple[int, int], source_times: set[datetime],
        prospective_source_time: datetime | None = None,
    ) -> bool:
        """A physical use route requires an independently valid creator."""
        entry = self.order_audit.get(identity)
        if (entry is None or not entry.get("causes")
                or entry.get("order_b_causes") or identity in self.initial_order_audit):
            return False
        return all(
            cause[0] == "parent-stop" and cause[1] == "S" and len(cause) > 4
            and (cause[4] in source_times or cause[4] == prospective_source_time)
            for cause in entry["causes"]
        )

    def _blocked_by_gate_owned_order(self, zone: EZone) -> bool:
        """Reject a nested parent-stop Order_A when the gate-owned A Order wins."""
        if "parent-stop" not in zone.order_causes:
            return False
        gate_owned = self._gate_owned_initial_order(zone.parent_stop_event_time)
        return (
            gate_owned is not None
            and gate_owned[2] < zone.order_first_time
        )


    def _rebuild_accepted_order_audit(
        self, numbered: list[EZone], supplemental_s_zones: Sequence[object] = (),
    ) -> list[EZone]:
        """Rebuild accepted parent-stop and reset-leg physical provenance."""
        self._accepted_e_source_identities = {
            (item.source_time, int(item.source_index)) for item in numbered
        }
        invalid_s_source_times = {
            source_time
            for source_time, _source_index in getattr(
                self, "invalid_s_root_identities", set()
            )
        } | {source_time for source_time, _index in self._accepted_e_source_identities}

        def valid_parent_stop_cause(cause: tuple[object, ...]) -> bool:
            if not cause or cause[0] != "parent-stop":
                return False
            # Suppressed/invalid S evidence may remain available internally for
            # E continuation geometry, but it never became an accepted S
            # behavior and therefore cannot create a physical parent-stop
            # Order_A. This includes S sources owned by accepted E. Valid
            # historical S causes at other sources remain authoritative.
            return not (
                cause[1] == "S"
                and len(cause) > 4
                and cause[4] in invalid_s_source_times
            )

        prior_order_audit = {
            identity: {
                **entry,
                "causes": {
                    cause for cause in entry.get("causes", set())
                    if valid_parent_stop_cause(cause)
                },
            }
            for identity, entry in self.order_audit.items()
        }
        self._clear_order_audit()
        self.register_order_b_reset_legs(self.order_b_legs)
        accepted_parents: list[tuple[str, object]] = [
            ("S", item) for item in self.s_zones
        ] + [("StopAll" if item.source_time in self.sequence_resets else "E", item)
             for item in numbered]
        for parent_type, parent in accepted_parents:
            stop = self._parent_stop(parent_type, parent)
            if stop is None:
                continue
            self._register_order_audit(parent_type, parent, stop[1])

        # Carried-live and accepted-live are use routes, not creation causes.
        # Preserve the original parent-stop Order_A provenance when final
        # reconciliation keeps a physical Order whose creating parent is no
        # longer a public behavior.
        for zone in numbered:
            identity = order_identity(zone.order_first_index, zone.order_break_index)
            if identity in self.order_audit:
                continue

            prior_entry = prior_order_audit.get(identity)
            reaction = self._opposite_by_first_index.get(zone.order_first_index)
            if (
                reaction is None
                or int(getattr(reaction, "break_idx", -1)) != zone.order_break_index
            ):
                reaction = SimpleNamespace(
                    mode=zone.order_mode,
                    first_idx=zone.order_first_index,
                    break_idx=zone.order_break_index,
                    box_top=zone.order_box_top,
                    box_top_source_idx=zone.order_box_top_source_index,
                    box_top_source_time=zone.order_box_top_source_time,
                    box_bottom=zone.order_box_bottom,
                    box_bottom_source_idx=zone.order_box_bottom_source_index,
                    box_bottom_source_time=zone.order_box_bottom_source_time,
                    behavior_internal=False,
                )

            causes: set[tuple[object, ...]] = set()
            if prior_entry is not None:
                causes.update(
                    cause for cause in prior_entry.get("causes", set())
                    if cause and cause[0] == "parent-stop"
                )

            initial_entry = self.initial_order_audit.get(identity)
            if initial_entry is not None:
                a_causes = initial_entry.get("a_causes") or [(
                    initial_entry.get("a_source_time"),
                    initial_entry.get("a_stop_event_time"),
                )]
                for a_source_time, a_stop_time in a_causes:
                    if a_source_time is None or a_stop_time is None:
                        continue
                    causes.add((
                        "parent-stop", "A", None, a_stop_time, a_source_time
                    ))

            if (
                not causes
                and "carried-live" in zone.order_causes
                and zone.parent_type == "S"
            ):
                parent_s = next((
                    item for item in [*self.s_zones, *supplemental_s_zones]
                    if int(getattr(item, "source_index")) == zone.parent_source_index
                    and getattr(item, "source_time") == zone.parent_source_time
                    and getattr(item, "order_first_index", None) == zone.order_first_index
                    and getattr(item, "order_break_index", None) == zone.order_break_index
                ), None)
                if parent_s is not None:
                    causes.add((
                        "parent-stop",
                        "A",
                        None,
                        getattr(parent_s, "a_stop_event_time"),
                        getattr(parent_s, "a_source_time"),
                    ))

            if zone.order_parent_stop_cause_time is not None:
                parent_label = zone.parent_type
                if zone.parent_type == "E":
                    parent_zone = next((
                        item for item in numbered
                        if item.source_index == zone.parent_source_index
                        and item.source_time == zone.parent_source_time
                    ), None)
                    if parent_zone is not None:
                        parent_label = f"E{parent_zone.number}"
                if zone.parent_source_time in self.sequence_resets:
                    parent_label = f"StopAll{self.sequence_resets[zone.parent_source_time]}"
                causes.add((
                    "parent-stop",
                    parent_label,
                    "" if zone.parent_source_time in self.sequence_resets else zone.family,
                    zone.parent_stop_event_time,
                    zone.parent_source_time,
                ))

            causes = {cause for cause in causes if valid_parent_stop_cause(cause)}
            if not causes:
                continue

            exact_cross = self._cross_order(
                zone.order_confirmation_time, as_decimal(zone.order_stop_level)
            )
            self.order_audit[identity] = {
                "reaction_number": zone.order_reaction_number,
                "reaction": reaction,
                "confirmation_time": zone.order_confirmation_time,
                "stop_level": zone.order_stop_level,
                "stop_source_index": zone.order_stop_source_index,
                "stop_source_time": zone.order_stop_source_time,
                "stop_cross": exact_cross,
                "causes": causes,
            }
            self._index_order_audit_identity(
                identity, zone.order_confirmation_time
            )

        # Order_A retention invariant: once a valid parent-stop physical Order
        # has entered the canonical ledger, later lifecycle reconciliation may
        # change who consumes it but must never delete its identity/provenance.
        for identity, prior_entry in prior_order_audit.items():
            prior_causes = {
                cause for cause in prior_entry.get("causes", set())
                if valid_parent_stop_cause(cause)
            }
            if not prior_causes:
                continue
            current = self.order_audit.get(identity)
            if current is not None:
                current_causes = current.setdefault("causes", set())
                assert isinstance(current_causes, set)
                current_causes.update(prior_causes)
                continue
            restored = {**prior_entry, "causes": set(prior_causes)}
            self.order_audit[identity] = restored
            self._index_order_audit_identity(
                identity, restored["confirmation_time"]
            )

        return sorted(
            numbered,
            key=lambda item: (item.source_time, item.source_index),
        )


    def rebuild_accepted_order_audit(
        self, zones: Sequence[EZone], supplemental_s_zones: Sequence[object] = (),
    ) -> list[EZone]:
        """Rebuild the canonical Order ledger after external E reconciliation.

        The pipeline may replace a final E branch with an earlier continuation
        built from consumed S evidence after ``detect()`` has completed.  That
        accepted branch must become authoritative for OrderAudit as well;
        the Order module keeps provenance out of the bridge projection.
        """
        return self._rebuild_accepted_order_audit(
            list(zones), supplemental_s_zones=supplemental_s_zones
        )


    def ensure_accepted_order_audit(
        self, zones: Sequence[EZone], supplemental_s_zones: Sequence[object] = (),
    ) -> list[EZone]:
        """Add audit coverage for externally restored accepted E zones.

        Visibility may restore an independent S-owned E root after StopAll
        reconciliation.  Rebuilding from only that post-StopAll E list would
        incorrectly discard physical Orders still needed by already-created
        StopAll/history, so rebuild the accepted subset and then merge back any
        previously canonical identities that were not superseded.
        """
        preserved = {
            identity: {**entry, "causes": set(entry.get("causes", set()))}
            for identity, entry in self.order_audit.items()
        }
        rebuilt = self._rebuild_accepted_order_audit(
            list(zones), supplemental_s_zones=supplemental_s_zones
        )
        invalid_s_source_times = {
            source_time for source_time, _index in (
                self.invalid_s_root_identities | self._accepted_e_source_identities
            )
        }
        for identity, entry in preserved.items():
            if identity in self.order_audit:
                continue
            entry["causes"] = {
                cause for cause in entry["causes"]
                if not (cause[1] == "S" and len(cause) > 4
                        and cause[4] in invalid_s_source_times)
            }
            if not entry["causes"] and not entry.get("order_b_causes"):
                continue
            self.order_audit[identity] = entry
            # The rebuild clears both ledger and index. Restoring only the
            # ledger makes the physical Order invisible to chronological
            # post-stop queries and downstream E/Order_B consumers.
            self._index_order_audit_identity(identity, entry["confirmation_time"])
        self._invalidate_carried_order_caches()
        return rebuilt


def _parent_stop_cause_key(cause: dict[str, object]) -> tuple[object, object, object, object]:
    return (
        cause.get("parentType"),
        cause.get("parentFamily"),
        cause.get("eventTime"),
        cause.get("parentSourceTime"),
    )


def _collect_s_ledger_entries(
    s_detector,
    accepted_a_sources: set[datetime] | None,
) -> list[tuple[dict[str, object], list[dict[str, object]]]]:
    """Collect A-owned Order_A entries with accepted creation causes."""
    combined: list[tuple[dict[str, object], list[dict[str, object]]]] = []
    if s_detector is None:
        return combined
    for entry in s_detector.order_audit.values():
        a_causes = entry.get("a_causes") or [(
            entry["a_source_time"], entry["a_stop_event_time"]
        )]
        if accepted_a_sources is not None:
            a_causes = [
                cause for cause in a_causes
                if cause[0] in accepted_a_sources
            ]
        if not a_causes:
            continue
        combined.append((entry, [
            {
                "kind": "parent-stop",
                "parentType": "A",
                "parentFamily": None,
                "eventTime": stop_time,
                "parentSourceTime": source_time,
            }
            for source_time, stop_time in a_causes
        ]))
    return combined


def _collect_e_ledger_entries(
    detector,
    accepted_a_sources: set[datetime] | None = None,
) -> list[tuple[dict[str, object], list[dict[str, object]]]]:
    """Collect E-stage Order entries using only accepted A parent-stop causes."""
    combined: list[tuple[dict[str, object], list[dict[str, object]]]] = []
    for entry in detector.order_audit.values():
        causes = [
            {
                "kind": "parent-stop",
                "parentType": cause[1],
                "parentFamily": cause[2],
                "eventTime": cause[3],
                "parentSourceTime": cause[4],
            }
            for cause in sorted(entry["causes"], key=str)
            if cause[0] == "parent-stop"
            and not (
                cause[1] == "A"
                and accepted_a_sources is not None
                and cause[4] not in accepted_a_sources
            )
        ]
        causes.extend(entry.get("order_b_causes", ()))
        if causes:
            combined.append((entry, causes))
    return combined


def _merge_prepared_identities(
    combined: list[tuple[dict[str, object], list[dict[str, object]]]],
    detector,
    start_index: int,
    end_index: int,
    required_identities: set[tuple[int, int]],
) -> list[dict[str, object]]:
    """Merge ledger rows by physical identity inside the presentation window."""
    merged: dict[tuple[int, int], dict[str, object]] = {}
    output: list[dict[str, object]] = []
    for entry, supplied_causes in combined:
        reaction = entry["reaction"]
        first_index = int(getattr(reaction, "first_idx"))
        identity = order_identity(first_index, getattr(reaction, "break_idx"))
        if (
            not start_index <= first_index <= end_index
            and identity not in required_identities
        ):
            continue
        existing = merged.get(identity)
        if existing is not None:
            existing_causes = existing["causes"]
            existing_causes.extend(
                cause for cause in supplied_causes
                if cause not in existing_causes
            )
            continue
        crossed = entry.get("stop_cross")
        if "stop_cross" not in entry:
            crossed = detector.cross_order(
                entry["confirmation_time"], entry["stop_level"]
            )
        prepared = {
            "entry": entry,
            "reaction": reaction,
            "causes": list(supplied_causes),
            "crossed": crossed,
        }
        merged[identity] = prepared
        output.append(prepared)
    return output


def _single_owner_parent_stop_causes(
    output: list[dict[str, object]],
) -> list[dict[str, object]]:
    """Keep one physical Order_A owner per exact parent-stop cause key."""
    parent_owner: dict[tuple[object, object, object, object], dict[str, object]] = {}
    parent_rank: dict[tuple[object, object, object, object], tuple[object, int, int]] = {}
    for item in output:
        reaction = item["reaction"]
        rank = (
            item["entry"]["confirmation_time"],
            int(getattr(reaction, "first_idx")),
            int(getattr(reaction, "break_idx")),
        )
        for cause in item["causes"]:
            if cause.get("kind") != "parent-stop":
                continue
            key = _parent_stop_cause_key(cause)
            previous = parent_rank.get(key)
            if previous is None or rank < previous:
                parent_rank[key] = rank
                parent_owner[key] = item

    deduped_output: list[dict[str, object]] = []
    for item in output:
        accepted_causes = []
        for cause in item["causes"]:
            if cause.get("kind") != "parent-stop":
                accepted_causes.append(cause)
                continue
            key = _parent_stop_cause_key(cause)
            if parent_owner.get(key) is item:
                accepted_causes.append(cause)
        if accepted_causes:
            item["causes"] = accepted_causes
            deduped_output.append(item)
    return deduped_output


def prepare_order_audit(
    detector,
    start_index: int,
    end_index: int,
    s_detector=None,
    accepted_a_sources: set[datetime] | None = None,
    required_identities: set[tuple[int, int]] | None = None,
):
    """Resolve final Order_A and Order_B identities before serialization."""
    required_identities = set(required_identities or set())
    combined = [
        *_collect_s_ledger_entries(s_detector, accepted_a_sources),
        *_collect_e_ledger_entries(detector, accepted_a_sources),
    ]
    output = _merge_prepared_identities(
        combined, detector, start_index, end_index, required_identities
    )
    return _single_owner_parent_stop_causes(output)


def accepted_audit_entry(
    entry: dict[str, object], accepted_sources: set
) -> dict[str, object] | None:
    """Return an E-facing A audit entry for one accepted A provenance.

    A physical order may be opened by more than one stopped A.  E still
    consumes one identity-keyed entry, so select the first accepted cause
    while retaining the complete cause list for presentation serialization.
    """
    causes = entry.get("a_causes") or [
        (entry["a_source_time"], entry["a_stop_event_time"])
    ]
    accepted_causes = [
        (source_time, stop_time)
        for source_time, stop_time in causes
        if source_time in accepted_sources
    ]
    if not accepted_causes:
        return None
    selected = accepted_causes[0]
    if (
        selected[0] == entry.get("a_source_time")
        and selected[1] == entry.get("a_stop_event_time")
        and accepted_causes == list(causes)
    ):
        return entry
    adjusted = dict(entry)
    adjusted["a_source_time"] = selected[0]
    adjusted["a_stop_event_time"] = selected[1]
    adjusted["a_causes"] = accepted_causes
    return adjusted


def accepted_audit_entries(
    order_audit: dict[tuple[int, int], dict[str, object]],
    accepted_sources: set[datetime],
) -> dict[tuple[int, int], dict[str, object]]:
    """Return Order_A entries whose creating A remains calculation-accepted."""
    return {
        identity: accepted
        for identity, entry in order_audit.items()
        for accepted in [accepted_audit_entry(entry, accepted_sources)]
        if accepted is not None
    }


def order_identity_is_internal(item, internal_identities):
    """Return whether a behavior's physical Order Reaction is internal."""
    first_index = getattr(item, "order_first_index", None)
    break_index = getattr(item, "order_break_index", None)
    if first_index is None or break_index is None:
        return False
    return order_identity(first_index, break_index) in internal_identities


class SOrderAuditMixin:
    """Physical Order_A and shared Order stop operations for S."""

    def _first_order_after(
        self, a_stop_event_time: datetime
    ) -> tuple[int, object, datetime] | None:
        """Resolve the first physical Order_A independently after each A stop.

        Opposite Order geometry must not inherit the normal same-direction
        Reaction stream's previous-First ownership.  A valid post-stop First
        can be nested inside an earlier, still-open opposite Reaction.  Keep
        the canonical identity/number when the geometry is already present;
        otherwise use reaction number zero (no invented public Reaction).
        The same immutable chosen physical identity is shared by S and E audit.
        """
        canonical = self._order_matches_after(a_stop_event_time)
        native = canonical[0] if canonical else None
        if self.initial_order_geometry is None:
            return native

        gate_index = self._main_index(a_stop_event_time)
        physical = self.initial_order_geometry(
            gate_index, a_stop_event_time, self.end_index
        )
        if physical is None or getattr(physical, "break_idx", None) is None:
            return native
        first_index = int(getattr(physical, "first_idx"))
        if first_index < gate_index:
            return native
        confirmation = self._reaction_confirmation_time(
            physical, self.order_direction
        )
        if confirmation <= a_stop_event_time:
            return native

        identity = reaction_identity(physical)
        mapped = self._opposite_by_first_index.get(first_index)
        if mapped is not None and reaction_identity(mapped[1]) == identity:
            number, physical = mapped
            confirmation = self._reaction_confirmation_time(
                physical, self.order_direction
            )
        else:
            # Order-only physical geometry is not a new canonical Reaction.
            number = 0
        independent = (number, physical, confirmation)
        if native is None:
            return independent
        # A stopped parent owns its first post-stop First, not whichever
        # unrelated continuous-stream Reaction happens to be published.
        if (
            first_index, confirmation
        ) < (
            int(getattr(native[1], "first_idx")), native[2]
        ):
            return independent
        return native


    def _order_matches_after(
        self, a_stop_event_time: datetime
    ) -> list[tuple[int, object, datetime]]:
        """Expose canonical opposite-Order chronology without changing ownership."""
        cached = self._order_matches_after_cache.get(a_stop_event_time)
        if cached is not None:
            return list(cached)

        gate_index = self._main_index(a_stop_event_time)
        position = bisect_right(
            self._opposite_order_confirmation_times, a_stop_event_time
        )
        matches = tuple(
            (number, reaction, confirmation)
            for confirmation, first_index, _break, number, reaction
            in self._opposite_order_matches[position:]
            if first_index >= gate_index
        )
        self._order_matches_after_cache[a_stop_event_time] = matches
        return list(matches)


    def _record_a_order_audit(
        self,
        zone: object,
        a_stop_event_time: datetime,
        order_match: tuple[int, object, datetime],
    ) -> None:
        """Attach one stopped-A creation cause to a physical Order identity."""
        source_time = getattr(zone, "source_time")
        order_number, order, order_confirmation_time = order_match
        (
            order_stop_level,
            order_stop_source_index,
            order_stop_source_time,
        ) = self._order_stop(order_number, order)
        identity = reaction_identity(order)
        cause = (source_time, a_stop_event_time)
        entry = self.order_audit.get(identity)
        if entry is None:
            entry = {
                "reaction_number": order_number,
                "reaction": order,
                "confirmation_time": order_confirmation_time,
                "stop_level": order_stop_level,
                "stop_source_index": order_stop_source_index,
                "stop_source_time": order_stop_source_time,
                "a_source_time": source_time,
                "a_stop_event_time": a_stop_event_time,
                "a_causes": [],
            }
            self.order_audit[identity] = entry
        a_causes = entry.setdefault("a_causes", [])
        if cause not in a_causes:
            a_causes.append(cause)


    def _audit_stopped_a(self, zone: object) -> None:
        """Record the independent physical Order created by one stopped A."""
        a_price = as_decimal(getattr(zone, "price"))
        a_stop = self._first_a_stop(a_price, self._a_confirmation_time(zone))
        if a_stop is None:
            return
        _, _, a_stop_event_time = a_stop
        order_match = self._first_order_after(a_stop_event_time)
        if order_match is None:
            return
        self._record_a_order_audit(zone, a_stop_event_time, order_match)


    def _order_stop(
        self, order_number: int, reaction: object
    ) -> tuple[Decimal, int, datetime]:
        return self.chronology.canonical_order_stop(
            self.order_direction,
            order_number,
            reaction,
            self.opposite_reactions,
            start_index=self.start_index,
        )


    def _order_stop_crossed(self, candle: object, level: Decimal) -> bool:
        if self.order_direction == "bearish":
            return as_decimal(getattr(candle, "high")) > level
        return as_decimal(getattr(candle, "low")) < level


    def _shared_order_stop_cross(
        self, confirmation: datetime, level: Decimal
    ) -> tuple[int, datetime, datetime] | None:
        """Return the first strict stop of an accepted Order after confirmation."""
        scan_start = max(confirmation, self.range_start)
        left = bisect_left(self.lower_times, scan_start)
        right = bisect_left(self.lower_times, self.range_end)
        if right > left and self.lower_index is not None:
            position = (
                self.lower_index.first_greater(left, right, level)
                if self.order_direction == "bearish"
                else self.lower_index.first_less(left, right, level)
            )
            if position is None:
                return None
            event_time = self.lower_times[position]
            index = self._main_index(event_time)
            return index, getattr(self.candles[index], "timestamp"), event_time

        for item in self.lower[left:right]:
            if self._order_stop_crossed(item, level):
                event_time = getattr(item, "timestamp")
                index = self._main_index(event_time)
                return index, getattr(self.candles[index], "timestamp"), event_time
        return None

