"""Recursive E-zone formation and reconciliation from accepted Order state.

The Order module owns physical creation, stops, reuse, and provenance. This
detector owns E source/decision geometry, chains, family, and numbering.
Cross-stage visibility and StopAll grouping remain lifecycle-owned.
"""

from __future__ import annotations

from heapq import merge
from itertools import groupby

from bisect import bisect_left
from dataclasses import dataclass, replace
from datetime import datetime
from decimal import Decimal
from heapq import heapify, heappop, heappush
from typing import Callable, Sequence

from core_utils import as_decimal, reaction_identity
from direction_policy import policy_for
from order_audit_engine import (
    OrderAuditEngineMixin, OrderBResetLeg, OrderMatch, PostBehaviorStop,
    discover_accepted_order_b_reset_legs, discover_order_b_reset_legs,
    dominant_post_behavior_stops, order_b_reset_event_time,
)


E_ZONE_VERSION = "6.16.2"
E_ZONE_IMPLEMENTATION_VERSION = "6.20.0"
E_ZONE_LAST_MODIFIED = "2026-11-17T20:14:54+03:30"


@dataclass(frozen=True, slots=True)
class EZone:
    direction: str
    family: str
    number: int
    parent_type: str
    parent_source_index: int
    parent_source_time: datetime
    parent_price: Decimal
    parent_stop_index: int
    parent_stop_time: datetime
    parent_stop_event_time: datetime
    order_direction: str
    order_reaction_number: int
    order_mode: str
    order_causes: tuple[str, ...]
    order_parent_stop_cause_time: datetime | None
    order_first_index: int
    order_first_time: datetime
    order_break_index: int
    order_break_time: datetime
    order_confirmation_time: datetime
    order_box_top: Decimal
    order_box_top_source_index: int
    order_box_top_source_time: datetime
    order_box_bottom: Decimal
    order_box_bottom_source_index: int
    order_box_bottom_source_time: datetime
    order_stop_level: Decimal
    order_stop_source_index: int
    order_stop_source_time: datetime
    source_index: int
    source_time: datetime
    price: Decimal
    decision_index: int
    decision_time: datetime
    decision_event_time: datetime


@dataclass(frozen=True, slots=True)
class _ParentStopProgress:
    scanned_until: datetime
    event: datetime | None


@dataclass(frozen=True, slots=True)
class _EReconciliationStep:
    source: int
    count: int
    active: tuple[EZone, ...]
    sequence_start: datetime | None


class _ReopenedERace(Exception):
    pass


@dataclass(frozen=True, slots=True)
class _ReconciledE:
    candidates: tuple[EZone, ...]
    numbered: tuple[EZone, ...]
    accepted: frozenset[tuple[datetime, int]]
    lifecycle_starts: frozenset[datetime]
    evidence: tuple
    steps: tuple[_EReconciliationStep, ...]
    native_numbered: tuple[EZone, ...]


class LiveEContinuation:
    """Retain exact E geometry and decisions across market updates.

    The active Order ledger is authoritative every time. A candidate can be
    reused only after selecting the same Order with the current ledger. The
    recursive ownership result is reusable only with the same candidates and
    ownership evidence, and without a dynamically reopened parent race.
    """

    def __init__(self) -> None:
        self._chronology: object | None = None
        self._scope: tuple | None = None
        self._dirty: datetime | None = None
        self._stops: dict[tuple, _ParentStopProgress] = {}
        self._previous_stops: dict[tuple, _ParentStopProgress] = {}
        self._extremes: dict[tuple, tuple[int, datetime, Decimal]] = {}
        self._previous_extremes: dict[tuple, tuple[int, datetime, Decimal]] = {}
        self._zones: dict[tuple, EZone] = {}
        self._previous_zones: dict[tuple, EZone] = {}
        self._reconciled: dict[tuple, _ReconciledE] = {}
        self._previous_reconciled: dict[tuple, _ReconciledE] = {}
        self._scoped_reconciliations: dict[tuple, _ReconciledE] = {}
        self._previous_scoped: dict[tuple, _ReconciledE] = {}
        self._main_index = None

    def advance(self, chronology: object, *, first_dirty_main: int) -> None:
        times = chronology.times
        if not times or not 0 <= first_dirty_main <= len(times):
            raise ValueError("The changed market index is outside the current chronology.")
        scope = (times[0], chronology.timeframe)
        self._dirty = (
            times[first_dirty_main] if first_dirty_main < len(times)
            else times[-1] + chronology.timeframe
        )
        same_market = scope == self._scope
        self._previous_stops, self._stops = (self._stops if same_market else {}), {}
        self._previous_extremes, self._extremes = (self._extremes if same_market else {}), {}
        self._previous_zones, self._zones = (self._zones if same_market else {}), {}
        self._previous_reconciled, self._reconciled = (self._reconciled if same_market else {}), {}
        self._previous_scoped, self._scoped_reconciliations = (
            self._scoped_reconciliations if same_market else {}
        ), {}
        self._main_index = None
        self._chronology, self._scope = chronology, scope

    def _dirty_time(self, detector: EZoneDetector) -> datetime:
        if detector.chronology is not self._chronology or self._dirty is None:
            raise ValueError("Advance the live E state to the detector's chronology.")
        return self._dirty

    def first_stop(
        self, detector: EZoneDetector, start: datetime, level: Decimal,
        *, less: bool, search: Callable[[datetime, datetime, Decimal], datetime | None],
    ) -> datetime | None:
        dirty = self._dirty_time(detector)
        key = (less, start, level)
        progress = self._stops.get(key)
        if progress is None:
            progress = self._previous_stops.get(key)
            if progress is not None and (progress.event is None or progress.event >= dirty):
                progress = _ParentStopProgress(min(progress.scanned_until, dirty), None)
        if progress is not None:
            self._stops[key] = progress
            if progress.event is not None:
                return progress.event if progress.event < detector.range_end else None
            start = max(start, progress.scanned_until)

        if start >= detector.range_end:
            return None
        event = search(start, detector.range_end, level)
        self._stops[key] = _ParentStopProgress(event or detector.range_end, event)
        return event

    def extreme(
        self, detector: EZoneDetector, start_index: int, end_index: int,
    ) -> tuple[int, datetime, Decimal]:
        dirty = self._dirty_time(detector)
        key = (detector.direction, start_index, end_index)
        result = self._extremes.get(key)
        if result is None and detector.times[end_index] < dirty:
            result = self._previous_extremes.get(key)
        if result is None:
            if self._main_index is None:
                from reaction_engine import LowerTimeframeIndex

                self._main_index = LowerTimeframeIndex(detector.candles)
            query = (self._main_index.range_minimum if detector.direction == "bullish"
                     else self._main_index.range_maximum)
            price, position = query(start_index, end_index + 1)
            result = (int(detector.candles[position].index), detector.times[position], price)
        self._extremes[key] = result
        return result

    def zone(
        self, detector: EZoneDetector, family: str, number: int, parent_type: str,
        parent: object, stop_event: datetime, match: OrderMatch,
        source: tuple[int, datetime, Decimal],
    ) -> EZone:
        dirty = self._dirty_time(detector)
        order_number, order, confirmation, level, stop_index, stop_time, crossed, causes, cause_time = match
        assert crossed is not None
        key = (
            detector.direction, family, number, parent_type, parent.source_index,
            parent.source_time, str(parent.price), stop_event, order_number,
            order.first_idx, order.break_idx, order.mode, order.box_top_source_idx,
            str(order.box_top), order.box_bottom_source_idx, str(order.box_bottom),
            confirmation, str(level), stop_index, stop_time, crossed, causes, cause_time,
            source[0], source[1], str(source[2]),
        )
        zone = self._zones.get(key)
        if zone is None and max(stop_event, crossed[2], confirmation) < dirty:
            zone = self._previous_zones.get(key)
        if zone is None:
            zone = detector._build_zone(family, number, parent_type, parent, stop_event, match, source)
        self._zones[key] = zone
        return zone

    def reconcile(self, detector: EZoneDetector, candidates: list[EZone]) -> list[EZone]:
        self._dirty_time(detector)
        if not candidates:
            return detector._compute_reconciliation(candidates)[0]

        identities = {(zone.order_first_index, zone.order_break_index) for zone in candidates}
        ledger = {}
        for identity in sorted(identities):
            entry = detector.order_audit.get(identity)
            ledger[identity] = (
                entry is not None, identity in detector.initial_order_audit,
                bool(entry and entry.get("order_b_causes")), frozenset(entry.get("causes", ())) if entry else (),
            )
        grouped = {}
        for zone in candidates:
            order = (zone.order_first_index, zone.order_break_index)
            dependency = (
                repr(zone), ledger[order], detector._blocked_by_gate_owned_order(zone),
                detector.sequence_priority(zone.parent_type, "red"),
                detector.sequence_priority(zone.parent_type, "blue"),
                zone.parent_source_index if zone.parent_type == "E" else zone.source_index,
            )
            grouped.setdefault(zone.source_index, []).append(dependency)
        parents = {}
        for item in detector.s_zones:
            parents.setdefault(item.source_index, []).append(
                (item.source_time, item.a_source_time, item.decision_event_time, item.color),
            )
        resets = frozenset(detector.sequence_resets.items())
        validity = frozenset(detector.invalid_s_root_identities), frozenset(detector.visual_lifecycle_starts)
        evidence = (grouped, parents, resets, validity)
        scope = (detector.direction, detector._live_scope)
        key = (
            tuple(map(id, candidates)),
            tuple((source, tuple(rows)) for source, rows in grouped.items()),
            tuple((source, tuple(rows)) for source, rows in parents.items()),
            resets, validity,
        )
        saved = self._reconciled.get(key) or self._previous_reconciled.get(key)
        if saved is not None:
            self._reconciled[key] = saved
            self._scoped_reconciliations[scope] = saved
            detector._last_candidate_zones = list(saved.candidates)
            detector._accepted_e_source_identities = set(saved.accepted)
            detector.visual_lifecycle_starts.update(saved.lifecycle_starts)
            return list(saved.numbered)

        previous = self._previous_scoped.get(scope)
        steps = []
        frontier = 0
        checkpoint = None
        if previous is not None and previous.evidence[3] == validity:
            old_groups, old_parents, old_resets, _ = previous.evidence
            frontier = detector._main_index(self._dirty)
            for source in grouped.keys() | old_groups.keys():
                before, after = old_groups.get(source, []), grouped.get(source, [])
                if before != after:
                    # A newly confirmed child can change the race of an
                    # already active parent before the child's source.
                    frontier = min(frontier, source, *(row[-1] for row in before + after))
            for source in parents.keys() | old_parents.keys():
                if parents.get(source) != old_parents.get(source):
                    frontier = min(frontier, source)
            for instant, _ in resets ^ old_resets:
                frontier = min(frontier, detector._main_index(instant))
            position = bisect_left(previous.steps, frontier, key=lambda step: step.source)
            steps.extend(previous.steps[:position])
            if position < len(previous.steps):
                checkpoint = previous.steps[position]
            else:
                checkpoint = previous.steps[-1]
                steps.pop()
        try:
            numbered, native = detector._compute_reconciliation(
                candidates, steps=steps, checkpoint=checkpoint, previous=previous, frontier=frontier,
            )
        except _ReopenedERace:
            # Dynamic Order races can insert a candidate before the apparent
            # frontier. Restart before mutating any native Order provenance.
            steps.clear()
            numbered, native = detector._compute_reconciliation(candidates, steps=steps)
        if not detector._reconciliation_reopened:
            saved = _ReconciledE(
                tuple(candidates), tuple(numbered),
                frozenset(detector._accepted_e_source_identities),
                frozenset(detector.visual_lifecycle_starts),
                evidence, tuple(steps), native,
            )
            self._reconciled[key] = self._scoped_reconciliations[scope] = saved
        return numbered


class EZoneDetector(OrderAuditEngineMixin):
    def __init__(
        self,
        direction: str,
        trend_reactions: Sequence[object],
        opposite_reactions: Sequence[object],
        s_zones: Sequence[object],
        opposite_resets: Sequence[object],
        chronology: object,
        start_index: int = 0,
        end_index: int | None = None,
        direct_geometry_finder: Callable[
            [str, int, int, datetime], object | None
        ] | None = None,
        blocked_order_first_times: set[datetime] | None = None,
        e_parent_order_first_exceptions: frozenset[tuple[datetime, datetime]] = frozenset(),
        initial_order_audit: dict[tuple[int, int], dict[str, object]] | None = None,
        sequence_resets: dict[datetime, int] | None = None,
        sequence_priority: Callable[[str, str], int] | None = None,
        invalid_s_root_identities: set[tuple[datetime, int]] | None = None,
        order_b_legs: Sequence[OrderBResetLeg] = (),
        live_continuation: LiveEContinuation | None = None,
        live_scope: tuple = (),
    ) -> None:
        if direction not in {"bullish", "bearish"}:
            raise ValueError("Direction must be 'bullish' or 'bearish'.")
        self.direction = direction
        self.policy = policy_for(direction)
        if sequence_priority is None:
            raise ValueError("EZoneDetector requires the shared sequence-priority resolver.")
        self.sequence_priority = sequence_priority
        self.invalid_s_root_identities = set(invalid_s_root_identities or set())
        self._accepted_e_source_identities: set[tuple[datetime, int]] = set()
        self.sequence_resets = sequence_resets or {}
        self.order_direction = chronology.opposite_direction(direction)
        self.chronology = chronology
        self.trend_reactions = list(trend_reactions)
        self.opposite_reactions = list(opposite_reactions)
        self.s_zones = sorted(
            s_zones,
            key=lambda item: (
                getattr(item, "source_time"),
                int(getattr(item, "source_index")),
            ),
        )
        self.opposite_resets = sorted(opposite_resets, key=self._reset_time)
        self.candles = chronology.candles
        self.lower = chronology.seconds
        self.lower_times = chronology.second_times
        self.lower_index = chronology.lower_index
        self.timeframe = chronology.timeframe
        self.times = chronology.times
        self.start_index = int(start_index)
        self.end_index = len(self.candles) - 1 if end_index is None else int(end_index)
        self.range_start = self.times[self.start_index]
        self.range_end = self.times[self.end_index] + self.timeframe
        if live_continuation is None:
            main_extremes = getattr(chronology, "_e_main_extremes", None)
            cached = main_extremes.get(direction) if main_extremes is not None else None
            if cached is None:
                self._stop_values = [
                    as_decimal(getattr(candle, self.policy.extreme_attr))
                    for candle in self.candles
                ]
                self._candle_codes = [int(getattr(candle, "index")) for candle in self.candles]
                self._extreme_sparse = self._build_extreme_sparse()
                if main_extremes is not None:
                    main_extremes[direction] = (
                        self._stop_values, self._candle_codes, self._extreme_sparse,
                    )
            else:
                self._stop_values, self._candle_codes, self._extreme_sparse = cached
        self.direct_geometry_finder = direct_geometry_finder
        self.blocked_order_first_times = blocked_order_first_times or set()
        self.e_parent_order_first_exceptions = e_parent_order_first_exceptions
        self.initial_order_audit = initial_order_audit or {}
        self.order_b_legs = tuple(order_b_legs)
        self._live_continuation = live_continuation
        self._live_scope = live_scope
        self._cross_order_cache: dict[
            tuple[datetime, Decimal], tuple[int, datetime, datetime] | None
        ] = {}
        # Performance implementation detail: canonical opposite Reactions are
        # immutable for one run, and their canonical Order stop depends only
        # on that canonical reaction number/geometry plus immutable chronology.
        # Cache only exact canonical objects; bounded/noncanonical Order_A
        # geometry intentionally stays on the authoritative uncached path.
        self._canonical_order_stop_cache: dict[
            int, tuple[Decimal, int, datetime]
        ] = {}
        # Performance implementation detail: the initial A-owned OrderAudit
        # ledger is immutable for one detector run. Materialize its expensive
        # strict-stop lookup once, then keep both chronological indexes and
        # the original physical identity semantics.
        self._initial_order_records_cache: tuple[tuple[
            datetime, datetime, int, object, Decimal, int, datetime,
            tuple[int, datetime, datetime] | None,
        ], ...] | None = None
        self._initial_order_first_times: list[datetime] | None = None
        self._initial_order_confirmation_times: list[datetime] | None = None
        self._initial_order_confirmation_records: tuple[tuple[
            datetime, datetime, int, object, Decimal, int, datetime,
            tuple[int, datetime, datetime] | None,
        ], ...] = ()
        self._initial_orders_by_first_time: dict[datetime, tuple[tuple[
            datetime, datetime, int, object, Decimal, int, datetime,
            tuple[int, datetime, datetime] | None,
        ], ...]] | None = None
        self._order_candidates_cache: dict[
            tuple[datetime, datetime | None, bool, bool], tuple[OrderMatch, ...]
        ] = {}
        self._carried_orders_cache: dict[
            tuple[datetime, datetime], tuple[OrderMatch, ...]
        ] = {}
        self._post_stop_orders_cache: dict[
            tuple[datetime, int], list[OrderMatch]
        ] = {}
        self._direct_parent_stop_cache: dict[
            tuple[datetime, datetime | None, bool, bool, datetime | None],
            tuple[int, object, datetime] | None,
        ] = {}
        self.order_audit: dict[tuple[int, int], dict[str, object]] = {}
        # Performance implementation detail: ``order_audit`` remains the
        # authoritative accepted ledger and preserves insertion/provenance
        # semantics. This secondary chronology index exists only to avoid a
        # full ledger scan when a parent can use only Orders confirmed after
        # its strict stop.
        self._order_audit_confirmation_index: list[
            tuple[datetime, int, int]
        ] = []
        self._trend_first_times = [
            self._reaction_first_time(item) for item in self.trend_reactions
        ]
        self._trend_confirmations = [
            self._confirmation_for(item, self.direction)
            for item in self.trend_reactions
        ]
        self._opposite_first_times = [
            self._reaction_first_time(item) for item in self.opposite_reactions
        ]
        self._opposite_confirmations = [
            self._confirmation(item) for item in self.opposite_reactions
        ]
        self._trend_by_confirmation = sorted(
            zip(
                self._trend_confirmations,
                self._trend_first_times,
                self.trend_reactions,
            ),
            key=lambda item: item[0],
        )
        self._trend_confirmation_times = [item[0] for item in self._trend_by_confirmation]
        self._opposite_reset_times_by_first: dict[int, list[datetime]] = {}
        for reset in self.opposite_resets:
            self._opposite_reset_times_by_first.setdefault(
                int(getattr(reset, "from_first_idx")), []
            ).append(self._reset_time(reset))
        self._opposite_by_first_index = {
            int(getattr(item, "first_idx")): item
            for item in self.opposite_reactions
        }
        # Performance implementation detail: retain the first canonical
        # position for each physical identity. Legacy linear searches used
        # ``next(...)``, so first-win semantics are preserved intentionally.
        self._opposite_identity_position: dict[tuple[int, int], int] = {}
        for position, item in enumerate(self.opposite_reactions):
            self._opposite_identity_position.setdefault(
                reaction_identity(item), position
            )
        self.visual_lifecycle_starts: set[datetime] = set()
        self._consumed_s_evidence: list[tuple[object, tuple[int, datetime]]] = []
        self._last_candidate_zones: list[EZone] = []

    @property
    def sequence_resets(self) -> dict[datetime, int]:
        return self._sequence_resets

    @sequence_resets.setter
    def sequence_resets(self, resets: dict[datetime, int]) -> None:
        """Publish hard boundaries and refresh their dependent query state once."""
        self._sequence_resets = dict(resets)
        self._sequence_reset_times = sorted(self._sequence_resets)
        for cache_name in (
            "_order_candidates_cache",
            "_carried_orders_cache",
            "_post_stop_orders_cache",
            "_direct_parent_stop_cache",
        ):
            cache = getattr(self, cache_name, None)
            if cache is not None:
                cache.clear()

    def _reset_time(self, reset: object) -> datetime:
        return self.chronology.reset_time(reset)

    def _main_index(self, value: datetime) -> int:
        return self.chronology.main_index(value, clamp=True)


    def _first_cross_position(
        self, left: int, right: int, level: Decimal, *, less: bool
    ) -> int | None:
        """Return the first strict lower-timeframe crossing in [left, right)."""
        if self.lower_index is not None:
            return (
                self.lower_index.first_less(left, right, level)
                if less
                else self.lower_index.first_greater(left, right, level)
            )
        field = "low" if less else "high"
        for position in range(left, right):
            value = as_decimal(getattr(self.lower[position], field))
            if value < level if less else value > level:
                return position
        return None

    def _stop_value(self, item: object) -> Decimal:
        return as_decimal(getattr(item, self.policy.extreme_attr))

    def _build_extreme_sparse(self) -> list[list[int]]:
        """Sparse table of first extreme candle positions over the main series."""
        values = self._stop_values
        n = len(values)
        if n == 0:
            return []
        less = self.direction == "bullish"
        st: list[list[int]] = [list(range(n))]
        k = 1
        while (1 << k) <= n:
            prev = st[-1]
            span = 1 << (k - 1)
            width = n - (1 << k) + 1
            cur = [0] * width
            for i in range(width):
                left = prev[i]
                right = prev[i + span]
                lv = values[left]
                rv = values[right]
                if (lv < rv) if less else (lv > rv):
                    cur[i] = left
                elif (rv < lv) if less else (rv > lv):
                    cur[i] = right
                else:
                    cur[i] = left if left <= right else right
            st.append(cur)
            k += 1
        return st

    def _extreme_position(self, left: int, right: int) -> int:
        """Return the first extreme candle position in ``[left, right]``."""
        values = self._stop_values
        less = self.direction == "bullish"
        length = right - left + 1
        if length <= 0:
            return left
        k = length.bit_length() - 1
        st = self._extreme_sparse
        i1 = st[k][left]
        i2 = st[k][right - (1 << k) + 1]
        lv = values[i1]
        rv = values[i2]
        if (lv < rv) if less else (lv > rv):
            return i1
        if (rv < lv) if less else (rv > lv):
            return i2
        return i1 if i1 <= i2 else i2


    def _first_parent_stop(
        self, source_time: datetime, level: Decimal
    ) -> tuple[int, datetime] | None:
        start = max(source_time, self.range_start)
        if self._live_continuation is None:
            event = self._search_parent_stop(start, self.range_end, level)
        else:
            event = self._live_continuation.first_stop(
                self, start, level, less=self.direction == "bullish", search=self._search_parent_stop,
            )
        return (self._main_index(event), event) if event is not None else None

    def _search_parent_stop(
        self, start: datetime, end: datetime, level: Decimal,
    ) -> datetime | None:
        return self._search_strict_cross(start, end, level, less=self.direction == "bullish")

    def _search_order_stop(
        self, start: datetime, end: datetime, level: Decimal,
    ) -> datetime | None:
        return self._search_strict_cross(start, end, level, less=self.order_direction != "bearish")

    def _search_strict_cross(
        self, start: datetime, end: datetime, level: Decimal, *, less: bool,
    ) -> datetime | None:
        left = bisect_left(self.lower_times, start)
        right = bisect_left(self.lower_times, end)
        position = self._first_cross_position(left, right, level, less=less)
        return self.lower_times[position] if position is not None else None

    def _cross_order(
        self, start: datetime, level: Decimal,
    ) -> tuple[int, datetime, datetime] | None:
        if self._live_continuation is None:
            return super()._cross_order(start, level)
        event = self._live_continuation.first_stop(
            self, max(start, self.range_start), level,
            less=self.order_direction != "bearish", search=self._search_order_stop,
        )
        if event is None:
            return None
        index = self._main_index(event)
        return index, self.times[index], event

    def _confirmation_for(self, reaction: object, direction: str) -> datetime:
        return self.chronology.reaction_confirmation(direction, reaction)

    def _confirmation(self, reaction: object) -> datetime:
        return self._confirmation_for(reaction, self.order_direction)

    def _reaction_first_time(self, reaction: object) -> datetime:
        return self.times[int(getattr(reaction, "first_idx"))]


    def _parent_stop(self, parent_type: str, parent: object) -> tuple[int, datetime] | None:
        if parent_type == "S":
            start = getattr(parent, "decision_event_time")
        else:
            # An E can only stop after the order-stop event that confirms it.
            start = getattr(parent, "decision_event_time")
        return self._first_parent_stop(start, as_decimal(getattr(parent, "price")))

    def parent_stop(
        self, parent_type: str, parent: object
    ) -> tuple[int, datetime] | None:
        """Public lifecycle API for the first strict parent stop."""
        return self._parent_stop(parent_type, parent)


    def _extreme_between(self, start: datetime, end: datetime) -> tuple[int, datetime, Decimal]:
        # E source ownership is candle-based: include the complete main candle
        # containing the parent stop and the complete main candle containing
        # the order stop. Lower-timeframe chronology decides whether each stop
        # happened, but it must not truncate either boundary candle's OHLC.
        start_index = max(self.start_index, self._main_index(start))
        end_index = min(self.end_index, self._main_index(end))
        if end_index < start_index:
            end_index = start_index
        if self._live_continuation is not None:
            return self._live_continuation.extreme(self, start_index, end_index)
        return self._find_extreme(start_index, end_index)

    def _find_extreme(self, start_index: int, end_index: int) -> tuple[int, datetime, Decimal]:
        position = self._extreme_position(start_index, end_index)
        return (
            self._candle_codes[position],
            self.times[position],
            self._stop_values[position],
        )

    def _zone(
        self, family: str, number: int, parent_type: str,
        parent: object, stop_event: datetime,
        *, e_owned_source_times: set[datetime] | None = None,
    ) -> EZone | None:
        # Every E-space cycle starts at the strict parent stop. Parent-stop
        # and reset-leg are creation causes; carried/accepted are use routes.
        inherited = (
            self._unconsumed_s_orders(parent, stop_event)
            if parent_type == "S"
            else []
        )
        gate_owned = self._gate_owned_initial_order(stop_event)
        carried = self._carried_orders_for_parent(parent, stop_event)
        self._register_order_audit(parent_type, parent, stop_event)
        post_stop_accepted = self._iter_post_stop_accepted_orders(
            parent, stop_event
        )
        inherited_stop_events = [
            item[6][2] for item in inherited if item[6] is not None
        ]
        continuous_deadline = (
            min(inherited_stop_events)
            if parent_type == "S" and not carried and inherited_stop_events
            else self.range_end
            if parent_type == "S" and not carried
            else None
        )
        direct = self.order_candidates(
            stop_event,
            continuous_deadline,
            allow_bounded_continue=(parent_type == "S"),
            allow_trend_leg_continue=(parent_type == "E"),
            e_parent=(parent_type == "E"),
        )
        # E consumption owns one global adjudication across every eligible
        # physical Order route. Route-local reductions must not discard a
        # later First before the canonical exact-stop tie-break can run.
        choice_key = lambda item: (item[6][2], -int(item[1].first_idx))

        def post_stop_choices():
            # The public accepted-Order query orders exact stop ties by
            # confirmation first. E adjudication instead orders by First;
            # materialize only that one stop-time group to preserve both.
            for _, group in groupby(post_stop_accepted, key=lambda item: item[6][2]):
                yield from sorted(group, key=choice_key)

        choices = merge(
            *(sorted((item for item in route if item[6] is not None), key=choice_key)
              for route in (direct, inherited, carried)),
            post_stop_choices(), key=choice_key,
        )
        owned_sources = e_owned_source_times if e_owned_source_times is not None else {
            source_time for source_time, _index in self._accepted_e_source_identities
        }
        order_match = None
        for match in choices:
            prospective_source = self._extreme_between(stop_event, max(stop_event, match[6][2]))
            if self._order_created_only_by_disowned_s(
                (int(match[1].first_idx), int(match[1].break_idx)),
                owned_sources, prospective_source[1],
            ):
                continue
            order_match = match
            break
        if order_match is None:
            return None
        if self._live_continuation is not None:
            return self._live_continuation.zone(
                self, family, number, parent_type, parent, stop_event, order_match, prospective_source,
            )
        return self._build_zone(family, number, parent_type, parent, stop_event, order_match, prospective_source)

    def _build_zone(
        self, family: str, number: int, parent_type: str, parent: object,
        stop_event: datetime, order_match: OrderMatch,
        prospective_source: tuple[int, datetime, Decimal],
    ) -> EZone:
        (
            order_number, order, order_confirmation, order_stop,
            stop_source, stop_source_time, crossed, order_causes,
            order_parent_stop_cause_time,
        ) = order_match
        assert crossed is not None
        decision_event = max(stop_event, crossed[2])
        decision_index = self._main_index(decision_event)
        decision_time = self.times[decision_index]
        source_index, source_time, price = prospective_source
        parent_stop_index = self._main_index(stop_event)
        order_first_index = int(getattr(order, "first_idx"))
        top_source = int(getattr(order, "box_top_source_idx"))
        bottom_source = int(getattr(order, "box_bottom_source_idx"))
        order_break_index = int(getattr(order, "break_idx"))
        return EZone(
            direction=self.direction,
            family=family,
            number=number,
            parent_type=parent_type,
            parent_source_index=int(getattr(parent, "source_index")),
            parent_source_time=getattr(parent, "source_time"),
            parent_price=as_decimal(getattr(parent, "price")),
            parent_stop_index=parent_stop_index,
            parent_stop_time=self.times[parent_stop_index],
            parent_stop_event_time=stop_event,
            order_direction=self.order_direction,
            order_reaction_number=order_number,
            order_mode=str(getattr(order, "mode")),
            order_causes=order_causes,
            order_parent_stop_cause_time=order_parent_stop_cause_time,
            order_first_index=order_first_index,
            order_first_time=self.times[order_first_index],
            order_break_index=order_break_index,
            order_break_time=self.times[order_break_index],
            order_confirmation_time=order_confirmation,
            order_box_top=as_decimal(getattr(order, "box_top")),
            order_box_top_source_index=top_source,
            order_box_top_source_time=self.times[top_source],
            order_box_bottom=as_decimal(getattr(order, "box_bottom")),
            order_box_bottom_source_index=bottom_source,
            order_box_bottom_source_time=self.times[bottom_source],
            order_stop_level=order_stop,
            order_stop_source_index=stop_source,
            order_stop_source_time=stop_source_time,
            source_index=source_index,
            source_time=source_time,
            price=price,
            decision_index=decision_index,
            decision_time=decision_time,
            decision_event_time=decision_event,
        )

    def set_consumed_s_evidence(
        self, evidence: Sequence[tuple[object, object]],
    ) -> None:
        """Register non-public S evidence that continues a stopped larger E."""
        self._consumed_s_evidence = [
            (
                s_zone,
                (int(getattr(owner, "source_index")), getattr(owner, "source_time")),
            )
            for s_zone, owner in evidence
        ]

    def _apply_consumed_s_evidence(self, zones: Sequence[EZone]) -> list[EZone]:
        result = list(zones)
        for s_zone, owner_id in self._consumed_s_evidence:
            owner = next(
                (
                    item for item in result
                    if (item.source_index, item.source_time) == owner_id
                ),
                None,
            )
            if owner is None:
                continue
            continuation = self.continuation_chain_from_s(owner, s_zone)
            result = self.replace_with_earlier_continuation(
                result, owner, continuation
            )
        return result

    def continuation_chain_from_s(
        self, owner: EZone, s_zone: object,
        independent_a_order_identities: frozenset[tuple[int, int]] = frozenset(),
    ) -> list[EZone]:
        """Build the E continuation opened by one S consumed by a stopped E.

        The S remains a calculation/evidence object, not a new public owner.
        Its first E inherits the stopped larger E's reconciled family and next
        number.  Recursive children are then rebuilt from the promoted E so
        Order discovery and stop chronology remain native E calculations.
        """
        source_identity = (s_zone.source_time, int(s_zone.source_index))
        if source_identity == (owner.source_time, int(owner.source_index)) or (
            source_identity in self._accepted_e_source_identities
        ):
            return []
        stopped = self._parent_stop("S", s_zone)
        if stopped is None:
            return []
        _, stop_event = stopped
        family = str(getattr(owner, "family"))
        number = int(getattr(owner, "number")) + 1
        parent_type = "S"
        parent: object = s_zone
        chain: list[EZone] = []
        seen_sources: set[int] = set()
        owned_sources = {source_time for source_time, _index in self._accepted_e_source_identities}
        owned_sources.add(owner.source_time)
        while True:
            zone = self._zone(family, number, parent_type, parent, stop_event,
                              e_owned_source_times=owned_sources)
            if zone is None or zone.source_index in seen_sources:
                break
            # The stopped-A ledger can hold a physical Order before that
            # independent cause reaches this detector's filtered E ledger.
            # An invalid S cannot create its own cause, but it may continue a
            # larger E with an Order already created by a stopped A.
            if (
                self._invalid_s_without_order_cause(zone)
                and (zone.order_first_index, zone.order_break_index)
                not in independent_a_order_identities
            ):
                break
            parent_source_time = getattr(parent, "source_time")
            if self._has_sequence_reset_between(
                parent_source_time, zone.source_time
            ):
                break
            chain.append(zone)
            seen_sources.add(zone.source_index)
            owned_sources.add(zone.source_time)
            next_stop = self._parent_stop("E", zone)
            if next_stop is None:
                break
            _, stop_event = next_stop
            parent_type, parent = "E", zone
            number += 1
        return chain

    def replace_with_earlier_continuation(
        self, base_zones: Sequence[EZone], owner: EZone, continuation: Sequence[EZone],
    ) -> list[EZone]:
        """Replace an owner's not-yet-decided descendant branch when an earlier one wins."""
        if not continuation:
            return list(base_zones)
        owner_id = (owner.source_index, owner.source_time)
        by_id = {(item.source_index, item.source_time): item for item in base_zones}

        def descends_from_owner(item: EZone) -> bool:
            current = item
            seen: set[tuple[int, datetime]] = set()
            while current.parent_type == "E":
                parent_id = (current.parent_source_index, current.parent_source_time)
                if parent_id == owner_id:
                    return True
                if parent_id in seen:
                    return False
                seen.add(parent_id)
                parent = by_id.get(parent_id)
                if parent is None:
                    return False
                current = parent
            return False

        direct_children = [
            item for item in base_zones
            if item.parent_type == "E"
            and (item.parent_source_index, item.parent_source_time) == owner_id
        ]
        first = continuation[0]
        if direct_children:
            winner = min(
                direct_children,
                key=lambda item: (item.decision_event_time, item.source_time),
            )
            if first.decision_event_time >= winner.decision_event_time:
                return list(base_zones)

        kept = [item for item in base_zones if not descends_from_owner(item)]
        merged = [*kept, *continuation]
        selected = self.resolve_same_source_conflicts(merged)
        self._accepted_e_source_identities = {
            (item.source_time, int(item.source_index)) for item in selected
        }
        return selected

    def resolve_same_source_conflicts(
        self, zones: Sequence[EZone],
    ) -> list[EZone]:
        """Keep exactly one accepted E behavior for each physical source candle.

        Candidate discovery may legitimately reach the same source through
        multiple S/E lineages.  Those alternatives are evidence only; once E
        reconciliation has assigned an accepted family/number, a lower-ranked
        alternative at that *same physical source* is not a second behavior.

        Dominance is the shared project rule: Red E outranks Blue E regardless
        of number, and within the same family the higher E number outranks the
        lower number.  Exact ties preserve the earlier accepted object so this
        resolver never rewrites provenance merely to deduplicate output.
        """
        winners: dict[tuple[int, datetime], EZone] = {}
        order: list[tuple[int, datetime]] = []

        def outranks(candidate: EZone, current: EZone) -> bool:
            candidate_priority = self.sequence_priority("e", candidate.family)
            current_priority = self.sequence_priority("e", current.family)
            if candidate_priority != current_priority:
                return candidate_priority > current_priority
            if candidate.family == current.family and candidate.number != current.number:
                return candidate.number > current.number
            return False

        for zone in zones:
            identity = (int(zone.source_index), zone.source_time)
            current = winners.get(identity)
            if current is None:
                winners[identity] = zone
                order.append(identity)
            elif outranks(zone, current):
                winners[identity] = zone

        result = [winners[identity] for identity in order]
        result.sort(
            key=lambda item: (
                item.source_time, item.source_index, item.decision_event_time,
            )
        )
        return result

    def restore_independent_s_roots(
        self, dominant_zones: Sequence[EZone],
    ) -> list[EZone]:
        """Restore calculation-valid E1 roots owned directly by accepted S.

        E dominance chooses which chain owns larger-module continuation, but
        formation of a new E behavior is independent: every accepted, stopped
        S may still form its own direct E1.  A reconciled dominant zone that
        came from that same S is therefore replaced by the original direct
        root (family/number from the S chain), while missing roots are added.
        Suppressed S evidence consumed by a larger E is not in ``self.s_zones``
        and cannot manufacture a competing E1 through this path.
        """
        # A physical source already owned by an accepted E cannot also keep
        # an S parent alive for downstream E-root restoration. Public lifecycle
        # finality already gives that candle to E; applying the same ownership
        # here prevents a provisional same-source S from manufacturing a later
        # E1 after reconciliation.
        dominant_sources = {
            (int(getattr(item, "source_index")), getattr(item, "source_time"))
            for item in dominant_zones
        }
        accepted_s = {
            (int(getattr(item, "source_index")), getattr(item, "source_time"))
            for item in self.s_zones
            if (int(getattr(item, "source_index")), getattr(item, "source_time"))
            not in dominant_sources
        }
        roots = [
            item for item in self._last_candidate_zones
            if item.parent_type == "S"
            and int(item.number) == 1
            and (item.parent_source_index, item.parent_source_time) in accepted_s
            and not self._invalid_s_without_order_cause(item)
        ]
        result = list(dominant_zones)
        pending_roots = [(root.source_time, root.source_index, ordinal, root)
                         for ordinal, root in enumerate(roots)]
        heapify(pending_roots)
        known_roots = set(roots)
        root_ordinal = len(roots)
        while pending_roots:
            _time, _index, _ordinal, root = heappop(pending_roots)
            parent_id = (root.parent_source_index, root.parent_source_time)
            # A root restored earlier in this pass can itself occupy the
            # physical source of another provisional S parent.
            if parent_id in dominant_sources:
                continue
            if self._order_created_only_by_disowned_s(
                (root.order_first_index, root.order_break_index),
                {source_time for _index, source_time in dominant_sources}, root.source_time,
            ):
                parent = next(item for item in self.s_zones
                              if (int(item.source_index), item.source_time) == parent_id)
                replacement = self._zone(
                    root.family, 1, "S", parent, root.parent_stop_event_time,
                    e_owned_source_times={time for _index, time in dominant_sources},
                )
                if replacement is not None and replacement not in known_roots:
                    known_roots.add(replacement)
                    heappush(pending_roots, (replacement.source_time, replacement.source_index,
                                             root_ordinal, replacement))
                    root_ordinal += 1
                continue
            same_parent = [
                item for item in result
                if item.parent_type == "S"
                and (item.parent_source_index, item.parent_source_time) == parent_id
            ]
            if same_parent:
                winner = min(
                    same_parent,
                    key=lambda item: (item.decision_event_time, item.source_time),
                )
                result = [item for item in result if item is not winner]
                result.append(root)
            elif not any(
                item.source_index == root.source_index
                and item.source_time == root.source_time
                and item.parent_type == root.parent_type
                and item.parent_source_index == root.parent_source_index
                and item.parent_source_time == root.parent_source_time
                for item in result
            ):
                result.append(root)
            dominant_sources.add((root.source_index, root.source_time))
        selected = self.resolve_same_source_conflicts(result)
        self._accepted_e_source_identities = {
            (item.source_time, int(item.source_index)) for item in selected
        }
        return selected

    def _invalid_s_without_order_cause(self, zone: EZone) -> bool:
        """Reject an invalid S root unless its Order has another creation cause."""
        if zone.parent_type != "S" or (
            zone.parent_source_time, zone.parent_source_index
        ) not in self.invalid_s_root_identities:
            return False
        identity = (zone.order_first_index, zone.order_break_index)
        if identity in self.initial_order_audit:
            return False
        entry = self.order_audit.get(identity)
        if entry is None:
            return True
        if entry.get("order_b_causes"):
            return False
        invalid_s_times = {
            source_time for source_time, _ in self.invalid_s_root_identities
        }
        return not any(
            cause[0] == "parent-stop" and not (
                cause[1] == "S" and cause[4] in invalid_s_times
            )
            for cause in entry.get("causes", ())
        )

    def _discover_candidate_chains(self) -> list[EZone]:
        """Build provisional recursive E chains from every stopped S parent.

        Calculation-invalid S geometry remains provisional discovery evidence.
        Its explicit invalid identity cannot create or retain a parent-stop
        Order_A cause or open a competing cross-family root over an occupied
        native E continuation. Valid historical S provenance and shared
        Order_B reset-leg causes remain eligible in the physical Order ledger.
        """
        # Discover S-owned orders before walking recursive E chains.  A valid
        # order formed inside an E parent's lifetime must remain available even
        # when that S branch is reconciled later than the E branch.
        for s_zone in self.s_zones:
            stop = self._parent_stop("S", s_zone)
            if stop is not None:
                self._register_order_audit("S", s_zone, stop[1])

        chains: list[tuple[object, list[EZone]]] = []
        candidates: list[EZone] = []
        for s_zone in self.s_zones:
            stop = self._parent_stop("S", s_zone)
            if stop is None:
                continue
            _, stop_event = stop

            # Every fully formed S starts an independent provisional E chain.
            # Final lifecycle eligibility is resolved after all candidate
            # continuations are visible, so exact same-source cross-family
            # collisions can be judged without timestamp/fixture exceptions.
            family = str(getattr(s_zone, "color"))
            number = 1

            parent_type: str = "S"
            parent: object = s_zone
            chain_sources: set[int] = set()
            chain: list[EZone] = []
            owned_sources = {source_time for source_time, _index in self._accepted_e_source_identities}
            while True:
                zone = self._zone(family, number, parent_type, parent, stop_event,
                                  e_owned_source_times=owned_sources)
                if zone is None:
                    break
                if zone.source_index in chain_sources:
                    break
                chain.append(zone)
                candidates.append(zone)
                chain_sources.add(zone.source_index)
                owned_sources.add(zone.source_time)
                parent_type, parent = "E", zone
                next_stop = self._parent_stop("E", zone)
                if next_stop is None:
                    break
                _, stop_event = next_stop
                number += 1
            if chain:
                chains.append((s_zone, chain))

        if not self.invalid_s_root_identities or not candidates:
            return candidates

        continuation_families: dict[tuple[datetime, int], set[str]] = {}
        for zone in candidates:
            if zone.parent_type != "E":
                continue
            identity = (zone.source_time, int(zone.source_index))
            continuation_families.setdefault(identity, set()).add(zone.family)

        blocked_roots: set[tuple[datetime, int]] = set()
        for s_zone, _ in chains:
            identity = (
                getattr(s_zone, "source_time"),
                int(getattr(s_zone, "source_index")),
            )
            if identity not in self.invalid_s_root_identities:
                continue
            s_family = str(getattr(s_zone, "color"))
            if any(
                family != s_family
                for family in continuation_families.get(identity, set())
            ):
                blocked_roots.add(identity)

        if not blocked_roots:
            return candidates

        return [
            zone
            for s_zone, chain in chains
            if (
                getattr(s_zone, "source_time"),
                int(getattr(s_zone, "source_index")),
            ) not in blocked_roots
            for zone in chain
        ]

    def _reconcile_candidate_chains(
        self, candidates: list[EZone]
    ) -> list[EZone]:
        """Resolve competing E chains into the accepted chronological lifecycle."""
        if self._live_continuation is not None:
            return self._live_continuation.reconcile(self, candidates)
        return self._compute_reconciliation(candidates)[0]

    def _compute_reconciliation(
        self, candidates: list[EZone], *, steps=None, checkpoint=None, previous=None, frontier=0,
    ) -> tuple[list[EZone], tuple[EZone, ...]]:
        # Resolve competing chains chronologically.  A stopped E is removed
        # from the active set immediately; it remains only as historical
        # output and cannot affect a later family or number.
        candidates = list(candidates)
        by_source: dict[int, list[EZone]] = {}
        for zone in candidates:
            by_source.setdefault(zone.source_index, []).append(zone)
        # A later E continuation can supersede a provisional E that was
        # started directly from an S before the continuation was confirmed.
        # Keep the later, deeper (bullish) / higher (bearish) structure.  This
        # This prevents a provisional S-owned object from consuming the active
        # chain before the later confirmed continuation.
        pending = [(min(item.source_time for item in group),
                    min(item.decision_event_time for item in group), source)
                   for source, group in by_source.items() if source >= frontier]
        heapify(pending)
        scheduled = {source for _, _, source in pending}
        known = set(candidates)
        regenerated: set[EZone] = set()
        self._reconciliation_reopened = False
        numbered = list(previous.native_numbered[:checkpoint.count]) if checkpoint is not None else []
        active = list(checkpoint.active) if checkpoint is not None else []
        accepted_sources = {(item.source_time, item.source_index) for item in numbered}
        accepted_source_times = {item.source_time for item in numbered}
        self._accepted_e_source_identities = accepted_sources
        sequence_start = checkpoint.sequence_start if checkpoint is not None else None

        candidates_by_source_time = {
            (item.source_index, item.source_time): item
            for item in candidates
        }
        s_by_source: dict[tuple[int, datetime], object] = {}
        for item in self.s_zones:
            s_by_source.setdefault((int(item.source_index), item.source_time), item)
        child_decision_by_parent: dict[tuple[int, datetime], datetime] = {}

        def index_child(zone: EZone) -> None:
            if zone.parent_type == "E":
                identity = (zone.parent_source_index, zone.parent_source_time)
                child_decision_by_parent[identity] = max(
                    child_decision_by_parent.get(identity, zone.decision_event_time),
                    zone.decision_event_time,
                )

        for zone in candidates:
            index_child(zone)

        def enqueue(zone: EZone | None, current_source: int) -> None:
            if zone is None or zone in known:
                return
            known.add(zone)
            regenerated.add(zone)
            candidates.append(zone)
            candidates_by_source_time[(zone.source_index, zone.source_time)] = zone
            index_child(zone)
            by_source.setdefault(zone.source_index, []).append(zone)
            if zone.source_index != current_source and zone.source_index not in scheduled:
                heappush(pending, (zone.source_time, zone.decision_event_time, zone.source_index))
                scheduled.add(zone.source_index)

        def valid_order(zone: EZone) -> bool:
            identity = (zone.order_first_index, zone.order_break_index)
            if self._order_created_only_by_disowned_s(identity, accepted_source_times, zone.source_time):
                return False
            return (
                not self._blocked_by_gate_owned_order(zone)
                and not self._invalid_s_without_order_cause(zone)
            )

        def parent_active(zone: EZone, seen: set[tuple[int, datetime]] | None = None) -> bool:
            if zone.parent_type == "S":
                parent_s = s_by_source.get((zone.parent_source_index, zone.parent_source_time))
                if parent_s is None or (
                    parent_s.source_time, int(parent_s.source_index)
                ) in accepted_sources:
                    return False
                if sequence_start is not None and (
                    parent_s.source_time <= sequence_start
                    or parent_s.a_source_time < sequence_start
                ):
                    return False
                prior_e = [
                    item for item in numbered
                    if getattr(item, "source_time")
                    < zone.source_time
                    and (sequence_start is None or item.source_time > sequence_start)
                ]
                if not prior_e:
                    return True
                prior = max(
                    prior_e, key=lambda item: getattr(item, "source_time")
                )
                rebuilt_after_e = (
                    getattr(parent_s, "source_time")
                    > getattr(prior, "source_time")
                    and getattr(parent_s, "a_source_time")
                    >= getattr(prior, "source_time")
                )
                # A still-unconsumed Red S is not invalidated by a nested
                # Blue E. Its later strict stop owns the Red transition.
                dominant_s = (
                    str(getattr(parent_s, "color")) == "red"
                    and prior.family == "blue"
                    and parent_s.source_time < prior.source_time
                    and not any(
                        item.parent_type == "S"
                        and item.parent_source_time == zone.parent_source_time
                        for item in numbered
                    )
                )
                return rebuilt_after_e or dominant_s
            if zone.parent_source_time == sequence_start:
                # The StopAll source is a valid order gate, but never an
                # active E whose family/number could leak across the reset.
                return True
            if any(
                item.source_index == zone.parent_source_index
                and item.source_time == zone.parent_source_time
                for item in active
            ):
                return True
            identity = (zone.parent_source_index, zone.parent_source_time)
            if seen is None:
                seen = set()
            if identity in seen:
                return False
            seen.add(identity)
            skipped_parent = candidates_by_source_time.get(identity)
            return (
                skipped_parent is not None
                and not valid_order(skipped_parent)
                and not self._invalid_s_without_order_cause(skipped_parent)
                and parent_active(skipped_parent, seen)
            )

        def stopped_by(zone: EZone, prior: EZone) -> bool:
            if zone.decision_event_time <= prior.decision_event_time:
                return False
            if self.direction == "bullish":
                return zone.price < prior.price
            return zone.price > prior.price

        while pending:
            _source_time, _decision_time, current_source = heappop(pending)
            scheduled.remove(current_source)
            if steps is not None:
                steps.append(_EReconciliationStep(current_source, len(numbered), tuple(active), sequence_start))
            group = by_source[current_source]
            # Another source can disown an Order after its E parent was
            # accepted. Reopen that parent's complete native race here.
            for item in group:
                if (self._order_created_only_by_disowned_s(
                            (item.order_first_index, item.order_break_index),
                            accepted_source_times, item.source_time)
                        and parent_active(item)):
                    parents = self.s_zones if item.parent_type == "S" else numbered
                    parent = next((parent for parent in parents
                                   if (parent.source_time, int(parent.source_index)) ==
                                   (item.parent_source_time, item.parent_source_index)), None)
                    if parent is None:
                        continue
                    if checkpoint is not None:
                        raise _ReopenedERace
                    family = item.family if item.parent_type == "S" else parent.family
                    number = item.number if item.parent_type == "S" else parent.number + 1
                    self._reconciliation_reopened = True
                    enqueue(self._zone(family, number, item.parent_type, parent,
                                       item.parent_stop_event_time,
                                       e_owned_source_times=accepted_source_times), current_source)
            eligible = [
                item for item in group
                if valid_order(item) and parent_active(item)
            ]
            if not eligible:
                continue
            # A lower-priority S cannot steal an active E continuation.
            # Red S may supersede Blue E, but no S supersedes Red E.
            # Color follows the accepted stopped parent's reconciled family.
            eligible = [
                item
                for item in eligible
                if not (
                    item.parent_type == "S"
                    and any(
                        stopped_by(item, owner)
                        and (owner.family == "red" or item.family == "blue")
                        and (child_decision := child_decision_by_parent.get(
                            (owner.source_index, owner.source_time)
                        )) is not None
                        and child_decision >= item.decision_event_time
                        for owner in active
                    )
                )
            ]
            if not eligible:
                continue
            current_owners = [
                item for item in eligible
                if not (
                    item.parent_type == "E"
                    and item.family == "blue"
                    and any(
                        str(getattr(s_zone, "color")) == "red"
                        and (s_zone.source_time, int(s_zone.source_index))
                        not in accepted_sources
                        and getattr(s_zone, "source_time")
                        > item.parent_source_time
                        and getattr(s_zone, "decision_event_time")
                        < item.parent_stop_event_time
                        for s_zone in self.s_zones
                    )
                )
            ]
            if current_owners:
                eligible = current_owners
            def ownership_priority(item: EZone) -> int:
                parent = next((prior for prior in active
                    if item.parent_type == "E"
                    and prior.source_time == item.parent_source_time), None)
                parent_family = parent.family if parent else item.family
                return self.sequence_priority(item.parent_type, parent_family)

            # One physical E source may be reachable through competing
            # Red/Blue S/E lineages.  Family priority is authoritative at the
            # physical source: Red outranks Blue even when the Blue candidate
            # happens to reach its decision a few lower-timeframe ticks
            # earlier.  Chronology remains the tie-breaker *within* the same
            # behavioral priority.  Applying this before chain reconciliation
            # prevents the dominant Red candidate from being discarded before
            # the final same-source resolver can see it.
            zone = min(
                eligible,
                key=lambda item: (
                    -ownership_priority(item),
                    item.decision_event_time,
                    item.parent_stop_event_time,
                ),
            )
            stopped_by_family: dict[str, list[EZone]] = {"red": [], "blue": []}
            for prior in active:
                if stopped_by(zone, prior):
                    stopped_by_family[prior.family].append(prior)

            parent_identity = (zone.parent_source_index, zone.parent_source_time)
            parent_is_active = (
                zone.parent_type == "S"
                or zone.parent_source_time == sequence_start
            ) or any(
                (item.source_index, item.source_time) == parent_identity
                for item in active
            )
            if not parent_is_active:
                # Without independent secondary Order creation causes, a child
                # cannot detach from an inactive parent lineage.
                continue

            owner = next((item for item in active
                          if zone.parent_type == "E"
                          and item.source_time == zone.parent_source_time), None)
            # Color follows the accepted stopped parent, not merely the most
            # recent S. A still-unbroken Red S does not recolor a nested E.
            parent_family = owner.family if owner is not None else zone.family

            if parent_family == "red":
                family = "red"
                number = (
                    max(item.number for item in stopped_by_family["red"]) + 1
                    if stopped_by_family["red"]
                    else 1
                )
            elif stopped_by_family["red"]:
                family = "red"
                number = max(item.number for item in stopped_by_family["red"]) + 1
            elif parent_family == "blue":
                family = "blue"
                number = (
                    max(item.number for item in stopped_by_family["blue"]) + 1
                    if stopped_by_family["blue"]
                    else 1
                )
            elif stopped_by_family["blue"]:
                family = "blue"
                number = max(item.number for item in stopped_by_family["blue"]) + 1
            else:
                family = zone.family
                number = 1
            stopped_ids = {
                (item.source_index, item.source_time)
                for values in stopped_by_family.values() for item in values
            }
            active = [
                item for item in active
                if (item.source_index, item.source_time) not in stopped_ids
            ]
            numbered_zone = replace(zone, family=family, number=number)
            numbered.append(numbered_zone)
            accepted_sources.add((numbered_zone.source_time, numbered_zone.source_index))
            accepted_source_times.add(numbered_zone.source_time)
            if zone.source_time in self.sequence_resets:
                active.clear()
                sequence_start = zone.source_time
            else:
                active.append(numbered_zone)
            # Original native children already participate in pending. Only
            # a regenerated parent needs a fresh descendant chain, including
            # when that parent's source is a hard-reset boundary.
            next_stop = self._parent_stop("E", numbered_zone) if zone in regenerated else None
            if next_stop is not None:
                self._reconciliation_reopened = True
                child = self._zone(numbered_zone.family, numbered_zone.number + 1,
                                   "E", numbered_zone, next_stop[1],
                                   e_owned_source_times=accepted_source_times)
                if child is not None and child.source_index > current_source:
                    enqueue(child, current_source)
        def collect_lineage(zone: EZone, seen: set[tuple[int, datetime]]) -> None:
            identity = (zone.source_index, zone.source_time)
            if identity in seen:
                return
            seen.add(identity)
            self.visual_lifecycle_starts.add(zone.parent_stop_event_time)
            if zone.parent_type == "S":
                return
            parent = candidates_by_source_time.get(
                (zone.parent_source_index, zone.parent_source_time)
            )
            if parent is not None:
                collect_lineage(parent, seen)

        lineage_seen: set[tuple[int, datetime]] = set()
        for zone in numbered:
            collect_lineage(zone, lineage_seen)

        if steps is not None:
            steps.append(_EReconciliationStep(len(self.candles), len(numbered), tuple(active), sequence_start))
        native = tuple(numbered)
        numbered = [replace(item, parent_type="StopAll")
                    if item.parent_type == "E"
                    and item.parent_source_time in self.sequence_resets
                    else item for item in numbered]
        self._accepted_e_source_identities = accepted_sources
        self._last_candidate_zones = list(candidates)
        return numbered, native


    def detect(self) -> list[EZone]:
        """Discover, reconcile and audit recursive E lifecycles."""
        self._accepted_e_source_identities.clear()
        self._clear_order_audit()
        self.register_order_b_reset_legs(self.order_b_legs)
        self.visual_lifecycle_starts.clear()
        candidates = self._discover_candidate_chains()
        self._last_candidate_zones = list(candidates)
        numbered = self._reconcile_candidate_chains(candidates)
        numbered = self._apply_consumed_s_evidence(numbered)
        numbered = self.resolve_same_source_conflicts(numbered)
        return self._rebuild_accepted_order_audit(numbered)


def detect_e_zones(
    direction: str,
    trend_reactions: Sequence[object],
    opposite_reactions: Sequence[object],
    s_zones: Sequence[object],
    opposite_resets: Sequence[object],
    chronology: object,
    start_index: int = 0,
    end_index: int | None = None,
    direct_geometry_finder: Callable[[str, int, int, datetime], object | None] | None = None,
    blocked_order_first_times: set[datetime] | None = None,
    initial_order_audit: dict[tuple[int, int], dict[str, object]] | None = None,
    sequence_priority: Callable[[str, str], int] | None = None,
    invalid_s_root_identities: set[tuple[datetime, int]] | None = None,
) -> list[EZone]:
    return EZoneDetector(
        direction,
        trend_reactions,
        opposite_reactions,
        s_zones,
        opposite_resets,
        chronology,
        start_index,
        end_index,
        direct_geometry_finder,
        blocked_order_first_times=blocked_order_first_times,
        initial_order_audit=initial_order_audit,
        sequence_priority=sequence_priority,
        invalid_s_root_identities=invalid_s_root_identities,
    ).detect()
