import test from "node:test";
import assert from "node:assert/strict";
import { drawingArray, normalizeHistorySnapshot, drawingToolOrder } from "../../src/chart/state.js";

test("legacy position drawings are omitted while unrelated saved drawings survive", () => {
  const line = { id: "line", type: "line" }, rect = { id: "rect", type: "rect" };
  const saved = [line, { id: "old-long", type: "long" }, rect, { id: "old-short", type: "short" }];
  assert.deepEqual(drawingArray({ drawings: saved }), [line, rect]);
  assert.equal(saved.length, 4, "Loading must leave the original saved evidence untouched.");
});

test("undo snapshots cannot restore retired positions or assessment labels", () => {
  const native = { id: "native", type: "indicator-label", text: "S" };
  const snapshot = normalizeHistorySnapshot({
    drawings: [{ id: "old", type: "long" }, { id: "measure", type: "measure" }],
    indicatorObjects: [native, { id: "buy", type: "indicator-position" },
      { id: "status", type: "indicator-label", setupStatusKind: "StopAll", text: "T" }],
  }, {});
  assert.deepEqual(snapshot, { drawings: [{ id: "measure", type: "measure" }], indicatorObjects: [native] });
});

test("saved toolbar layouts drop removed tools without reordering retained tools", () => {
  assert.deepEqual(drawingToolOrder([["cursor"], ["line"], ["measure"], ["rect"]],
    ["rect", "long", "measure", "cursor", "short", "line"]), ["rect", "measure", "cursor", "line"]);
});
