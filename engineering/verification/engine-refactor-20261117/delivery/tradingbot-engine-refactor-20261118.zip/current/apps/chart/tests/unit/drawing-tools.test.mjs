import test from "node:test";
import assert from "node:assert/strict";

import { calculateMeasureStats } from "../../src/drawings/drawing-math.js";

test("measure stats include duration, candle count, price delta, and percentage", () => {
  assert.deepEqual(calculateMeasureStats({ time: 100, price: 100 }, { time: 220, price: 110 }, 60), {
    durationSeconds: 120,
    bars: 2,
    priceDelta: 10,
    percentage: 10,
    durationLabel: "2m",
  });
});
